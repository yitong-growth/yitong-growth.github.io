/* 可编辑默认配置；浏览器「平台配置」会保存本机覆盖值。空链接表示尚未配置。 */
window.YT_CONFIG = {
  version: '2.4.0',
  xiaoguan: {endpoint:'', model:''},
  platforms: {
    family: {name:'VR 家园沟通配套软件', url:'', note:'戴 VR 眼镜，在独立配套软件中训练。导出记录后回到这里导入。'},
    environment: {name:'环境创设软件', url:'', note:'在环创软件中完成设计，学生上传作品，教师登录独立评价区评阅。'},
    life: {name:'智能娃娃平台', url:'', note:'在智能娃娃配套平台完成实训，导出成绩后回到这里导入。'}
  },
  rules: {pass:60, target:80, excellent:90},
  resources: []
};
