window.YT_PUBLIC_URL=location.protocol==='file:'?'':new URL('./',location.href).href;
