(function(){
  'use strict';
  let promptEvent;
  const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function show(html){
    let dialog=document.querySelector('#local-app-dialog');
    if(!dialog){dialog=document.createElement('dialog');dialog.id='local-app-dialog';dialog.className='local-app-dialog';dialog.innerHTML='<button class="local-app-dialog-close" aria-label="关闭使用说明">×</button><div class="local-app-dialog-body"></div>';document.body.append(dialog);dialog.querySelector('button').addEventListener('click',()=>dialog.close());}
    dialog.querySelector('.local-app-dialog-body').innerHTML=html;dialog.showModal();
  }
  function storageHelp(){show('<h2>这份成长，保存在此设备</h2><p>无需 ChatGPT 账号。使用页面里的学号／手机号登录，也可注册本机学习账号。</p><div class="local-app-hint"><b>成绩、作品、学习任务与笔记</b><p>保存在当前浏览器，联网不会自动上传，也不会同步到别人的设备。</p></div><p>换设备前，在“数据与作品”导出<strong>完整备份</strong>；到新设备注册相同学号，进入相同数据区恢复。请在清除浏览器数据前先备份。</p><p>教师评价沿用本机流程：在同一浏览器中，学生提交并退出，教师登录独立评价区批阅。此阶段不提供远程收作业。</p><p class="local-app-hint">电脑离线文件版和在线网页的浏览器存储分别保存，需要用完整备份迁移。以后接入学校服务器时再增加统一账号和同步。</p>');}
  function installGuide(){
    if(promptEvent){const current=promptEvent;promptEvent=null;current.prompt();current.userChoice.catch(()=>{});return;}
    const file=location.protocol==='file:',url=window.YT_PUBLIC_URL||'';
    show('<h2>把益童成长放到主屏幕</h2><div class="local-app-intro"><img src="icons/icon-192.png" alt="益"><div><b>益童成长智能体</b><p>原来的课程内容，像 App 一样打开</p></div></div>'+(file?'<p class="local-app-hint">您正在使用电脑离线文件版。手机安装请先打开'+(url?' <a href="'+esc(url)+'" target="_blank" rel="noopener">益童成长网页版</a>':'教师分享的课程网址')+'。</p>':'')+'<ol><li><b>电脑／安卓</b>：用 Edge 或 Chrome 打开网页版，选择浏览器菜单中的“安装应用”或“添加到主屏幕”。出现安装提示时也可直接安装。</li><li><b>苹果手机／iPad</b>：用 Safari 打开网页版，点分享 → 添加到主屏幕 → 添加。</li></ol><p class="local-app-hint">首次打开网页版需要联网，课程素材准备好后可离线打开。未接入模型的小管清单功能、图表、成绩导入和本机作品可以离线使用；外部平台及模型服务仍需要相应网络。</p><p>可将网址发给学生直接打开，无需 ChatGPT 或 GitHub 账号。学校网络能否访问在线地址需实际测试；电脑离线文件版不依赖外网。</p><p>跨设备搬移记录使用完整备份，每台设备分别保存。</p>');
  }
  document.addEventListener('DOMContentLoaded',()=>{
    const dock=document.createElement('div');dock.className='local-app-dock';dock.innerHTML='<button data-local-tool="storage">本机保存</button><button class="local-app-install" data-local-tool="install">安装 App</button>';document.body.append(dock);
    dock.querySelector('[data-local-tool="storage"]').addEventListener('click',storageHelp);dock.querySelector('[data-local-tool="install"]').addEventListener('click',installGuide);
    if(location.protocol==='file:')return;
    const manifest=document.createElement('link');manifest.rel='manifest';manifest.href='manifest.webmanifest';document.head.append(manifest);
    if('serviceWorker' in navigator&&window.isSecureContext){
      navigator.serviceWorker.register('sw.js',{scope:'./'}).then(async()=>{
        await navigator.serviceWorker.ready;
        dock.querySelector('[data-local-tool="storage"]').textContent='本机保存 · 可离线打开';
      }).catch(()=>{dock.querySelector('[data-local-tool="storage"]').textContent='本机保存';});
    }
  });
  window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();promptEvent=event;});
  window.addEventListener('appinstalled',()=>{const button=document.querySelector('[data-local-tool="install"]');if(button)button.textContent='App 已安装';});
})();
