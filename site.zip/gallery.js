/* 本地绘制的课程示例设计图。不是学生提交，不含成绩，不写入学生数据库。 */
window.YT_GALLERY = [
  {
    "id": "course-01",
    "src": "assets/works/work-01.svg",
    "title": "感官探索小天地",
    "age": "1—3 岁",
    "category": "感官与材料",
    "description": "低位分层材料架，结合触觉、抓握与自主取放，保留成人观察空间。",
    "kind": "course-example"
  },
  {
    "id": "course-02",
    "src": "assets/works/work-02.svg",
    "title": "分龄阅读森林",
    "age": "2—6 岁",
    "category": "阅读与表达",
    "description": "用低位书架、软垫与熟悉的故事材料，支持不同年龄自主选书和共同阅读。",
    "kind": "course-example"
  },
  {
    "id": "course-03",
    "src": "assets/works/work-03.svg",
    "title": "自然观察小花园",
    "age": "3—6 岁",
    "category": "自然与探索",
    "description": "把种植、观察与记录放在同一区域，让环境随着儿童的问题持续更新。",
    "kind": "course-example"
  },
  {
    "id": "course-04",
    "src": "assets/works/work-04.svg",
    "title": "建构游戏乐园",
    "age": "2—6 岁",
    "category": "建构与合作",
    "description": "材料按操作能力分层收纳，留出共享建构空间，支持多种组合和合作表达。",
    "kind": "course-example"
  },
  {
    "id": "course-05",
    "src": "assets/works/work-05.svg",
    "title": "我会照顾自己",
    "age": "1—6 岁",
    "category": "生活与自主",
    "description": "以清晰的取放标识和操作步骤，支持生活照料中的自主尝试与成人陪伴。",
    "kind": "course-example"
  },
  {
    "id": "course-06",
    "src": "assets/works/work-06.svg",
    "title": "情绪安静小屋",
    "age": "2—6 岁",
    "category": "情感与照料",
    "description": "设置可被成人看见的安静角，提供熟悉玩偶与绘本，尊重儿童的停留选择。",
    "kind": "course-example"
  },
  {
    "id": "course-07",
    "src": "assets/works/work-07.svg",
    "title": "家园共育故事墙",
    "age": "0—6 岁",
    "category": "家庭与连接",
    "description": "以家庭故事、成长记录和共同约定建立家园连接，保护儿童与家庭信息。",
    "kind": "course-example"
  },
  {
    "id": "course-08",
    "src": "assets/works/work-08.svg",
    "title": "儿童的四季主题墙",
    "age": "3—6 岁",
    "category": "参与与表达",
    "description": "展示过程与儿童表达，保留可移动、可更新的区域，让儿童参与主题生成。",
    "kind": "course-example"
  },
  {
    "id": "course-09",
    "src": "assets/works/work-09.svg",
    "title": "户外自然探索路线",
    "age": "2—6 岁",
    "category": "户外与游戏",
    "description": "围绕种植、沙水与自然材料组织观察路线，按分龄活动需要核对现场条件。",
    "kind": "course-example"
  },
  {
    "id": "course-10",
    "src": "assets/works/work-10.svg",
    "title": "托幼衔接共享空间",
    "age": "2—6 岁",
    "category": "衔接与分龄",
    "description": "保留熟悉的日常习惯，同时设置低龄自主探索与幼儿合作建构的分层材料。",
    "kind": "course-example"
  }
];
