(function(){
  'use strict';
  const xml=s=>{const d=new DOMParser().parseFromString(s,'application/xml');if(d.getElementsByTagName('parsererror').length)throw Error('Excel 内部 XML 格式损坏');return d;};
  const nodes=(d,name)=>Array.from(d.getElementsByTagNameNS('*',name));
  const text=(d,name)=>nodes(d,name)[0]?.textContent||'';
  function colIndex(ref){const a=(ref.match(/^[A-Z]+/)||['A'])[0];return [...a].reduce((n,c)=>n*26+c.charCodeAt(0)-64,0)-1;}
  async function openExcel(buffer){
    const z=await JSZip.loadAsync(buffer); const files=Object.values(z.files);
    if(files.length>2000)throw Error('Excel 文件内部条目过多，请另存为简化表格');
    let total=0;for(const f of files){total+=f._data?.uncompressedSize||0;}if(total>30*1024*1024)throw Error('Excel 解压后超过 30 MB，请只保留成绩表');
    const read=async name=>{const f=z.file(name);if(!f)throw Error('Excel 缺少 '+name);return xml(await f.async('string'));};
    const book=await read('xl/workbook.xml'),rels=await read('xl/_rels/workbook.xml.rels');
    const targets=new Map(nodes(rels,'Relationship').map(n=>[n.getAttribute('Id'),n.getAttribute('Target')]));
    const sheets=nodes(book,'sheet').map(n=>{const t=targets.get(n.getAttribute('r:id')||n.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id'));return {name:n.getAttribute('name'),path:t?.startsWith('/')?t.slice(1):'xl/'+t?.replace(/^\.\//,'')};});
    if(!sheets.length)throw Error('Excel 中没有工作表');
    let shared=[];if(z.file('xl/sharedStrings.xml'))shared=nodes(await read('xl/sharedStrings.xml'),'si').map(s=>nodes(s,'t').map(n=>n.textContent).join(''));
    let styles=[],custom=new Map();if(z.file('xl/styles.xml')){const d=await read('xl/styles.xml');custom=new Map(nodes(d,'numFmt').map(n=>[Number(n.getAttribute('numFmtId')),n.getAttribute('formatCode')]));const x=nodes(d,'cellXfs')[0];if(x)styles=nodes(x,'xf').map(n=>Number(n.getAttribute('numFmtId')));}
    const date1904=nodes(book,'workbookPr')[0]?.getAttribute('date1904');
    async function table(index){
      const doc=await read(sheets[index].path),rows=[],warnings=[];
      const rr=nodes(doc,'row');if(rr.length>5001)throw Error('单表最多 5000 条记录，请分批导入');
      for(const row of rr){const values=[];for(const c of nodes(row,'c')){
        const col=colIndex(c.getAttribute('r')||'A1');if(col>200)throw Error('Excel 列数过多，请只保留成绩列');
        const type=c.getAttribute('t'),val=text(c,'v');
        if(nodes(c,'f').length){if(!nodes(c,'v').length||val==='')throw Error('公式单元格缺少缓存值，请在 Excel 中计算并保存，或粘贴为值');if(!warnings.length)warnings.push('检测到 Excel 公式，读取保存时的缓存值，浏览器不重新计算公式。');}
        let value=type==='s'?shared[Number(val)]||'':type==='inlineStr'?nodes(c,'t').map(n=>n.textContent).join(''):type==='b'?(val==='1'?'是':'否'):val;
        if(type==='e')throw Error('Excel 含错误单元格 '+c.getAttribute('r')+'：'+value);
        const fmt=styles[Number(c.getAttribute('s')||0)],code=custom.get(fmt)||'';
        if(!type || type==='n'){
          if(value!==''&&Number.isFinite(Number(value)))value=Number(value);
          const isDate=(fmt>=14&&fmt<=22)||(fmt>=45&&fmt<=47)||/[yd]/i.test(code.replace(/"[^"]*"|\[[^\]]*\]/g,''));
          if(isDate&&typeof value==='number')value=YT.dateValue(value+(['1','true'].includes(date1904)?1462:0));
        }
        values[col]=value;
      }if(values.some(v=>v!==''&&v!==undefined))rows.push(values);}
      if(rows.length<2)throw Error('工作表需要第一行表头和至少一条记录');
      const rawHeaders=rows.shift();const headers=Array.from({length:rawHeaders.length},(_,i)=>String(rawHeaders[i]??'').trim());
      if(headers.some(h=>!h)||new Set(headers).size!==headers.length)throw Error('Excel 第一行表头不能为空或重复');
      if(rows.some(r=>r.length>headers.length))throw Error('工作表数据列超过表头列数');
      return {headers,rows,warnings};
    }
    return {sheets,table};
  }
  window.YTImporter={openExcel,async read(file){
    if(file.size>5*1024*1024)throw Error('文件超过 5 MB，请分批导入');
    const buffer=await file.arrayBuffer();
    if(/\.xlsx$/i.test(file.name)){const workbook=await openExcel(buffer);return {workbook,table:await workbook.table(0)};}
    if(!/\.(csv|tsv)$/i.test(file.name))throw Error('支持 .csv、.tsv、.xlsx；旧版 .xls 请先另存为 .xlsx');
    let encoding='UTF-8',s=new TextDecoder('utf-8').decode(buffer);
    if(s.includes('\uFFFD')){s=new TextDecoder('gb18030').decode(buffer);encoding='GB18030';}
    return {table:YT.parseCSV(s),encoding};
  }};
})();
