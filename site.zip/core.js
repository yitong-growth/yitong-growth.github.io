(function(root, factory){
  const api=factory(); if(typeof module==='object' && module.exports) module.exports=api; else root.YT=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const domains=[
    {id:'family',name:'家园共育',ability:'家园沟通',color:'#378aa3',icon:'chat',skills:['情绪识别','专业依据','话术选择','解决路径'],task:'家长焦虑质疑沟通'},
    {id:'environment',name:'环境创设',ability:'环境管理',color:'#4b9277',icon:'blocks',skills:['安全性','分龄适宜性','互动性','教育价值'],task:'分龄环创板设计'},
    {id:'life',name:'一日生活',ability:'生活照护',color:'#b48b32',icon:'heart',skills:['喂养照护','拍嗝哄睡','生活组织','安全应急'],task:'智能娃娃照护实训'}
  ];
  const fields=[
    ['studentId','学号',true,['student_id','studentId','学号','学生编号']],
    ['name','姓名',false,['student_name','name','姓名','学生姓名']],
    ['domain','模块',true,['domain','module','模块','领域','三域']],
    ['skill','技能',true,['skill','技能','评价维度','能力项']],
    ['task','任务',false,['task','scenario','任务','训练任务','情境']],
    ['score','成绩',true,['score','成绩','分数','得分']],
    ['maxScore','满分',false,['max_score','maxScore','满分','总分']],
    ['date','训练时间',true,['trained_at','date','训练时间','训练日期','日期']],
    ['attempt','训练轮次',false,['attempt','round','训练轮次','轮次','次数']],
    ['feedback','评价记录',false,['feedback','评价记录','反馈','评语']],
    ['source','来源平台',false,['source','来源平台','平台']],
    ['recordId','原始记录编号',false,['record_id','recordId','原始记录编号','记录编号']],
    ['kind','数据性质',false,['data_kind','kind','数据性质','数据类型']],
    ['responseSeconds','回应秒数',false,['response_seconds','回应秒数','回应时长']],
    ['ageGroup','年龄组',false,['age_group','年龄组','年龄段']],
    ['supportAction','训练支持动作',false,['support_action','训练支持动作','智能体支持']],
    ['dataset','档案标记',false,['dataset','档案标记']]
  ];
  const clone=x=>JSON.parse(JSON.stringify(x));
  function domainId(x){
    const t=String(x||'').trim(); const map={family:'family',environment:'environment',life:'life','家园共育':'family','家园沟通':'family','环境创设':'environment','环境管理':'environment','一日生活':'life','生活照护':'life'};
    return map[t]||'';
  }
  function parseCSV(input){
    let text=String(input).replace(/^\uFEFF/,'');
    const first=text.split(/\r?\n/)[0]||'';
    const delimiter=first.includes('\t') && !first.includes(',')?'\t':',';
    const rows=[];let row=[],field='',quoted=false,ended=false;
    for(let i=0;i<text.length;i++){
      const c=text[i];
      if(quoted){if(c==='"'){if(text[i+1]==='"'){field+='"';i++;}else{quoted=false;ended=true;}}else field+=c;}
      else if(c==='"'){if(field.trim()||ended) throw Error('CSV 引号格式错误'); quoted=true;}
      else if(c===delimiter){row.push(field);field='';ended=false;}
      else if(c==='\n'||c==='\r'){if(c==='\r' && text[i+1]==='\n')i++;row.push(field);if(row.some(v=>v.trim()))rows.push(row);row=[];field='';ended=false;}
      else {if(ended && c.trim())throw Error('CSV 引号后存在多余字符');field+=c;}
    }
    if(quoted)throw Error('CSV 存在未闭合的引号');
    row.push(field);if(row.some(v=>v.trim()))rows.push(row);
    if(rows.length<2)throw Error('文件需要一行表头和至少一条记录');
    const headers=rows.shift().map(v=>v.trim());
    if(new Set(headers).size!==headers.length || headers.some(h=>!h))throw Error('表头不能为空或重复');
    if(rows.some(r=>r.length>headers.length))throw Error('CSV 列数超过表头，请检查逗号或引号');
    return {headers,rows};
  }
  function autoMap(headers){const m={};fields.forEach(([k,, ,aliases])=>{m[k]=headers.findIndex(h=>aliases.some(a=>a.toLowerCase()===String(h).trim().toLowerCase()));});return m;}
  function dateValue(v){
    if(typeof v==='number'){
      if(v<1||v>100000)return '';
      return new Date(Date.UTC(1899,11,30)+Math.round(v*86400000)).toISOString().slice(0,19);
    }
    const raw=String(v||'').trim().replace(/\//g,'-');
    const iso=raw.match(/^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.\d{1,3})?(Z|[+-]\d{2}:\d{2})$/);
    if(iso){if(!dateValue(iso[1]))return '';const ms=Date.parse(raw);if(!Number.isFinite(ms))return '';return new Date(ms+8*3600000).toISOString().slice(0,19);}
    const s=raw.replace(/\.\d{1,3}$/,'');
    const match=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T ](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if(!match)return '';
    const [y,mo,d,h,mi,se]=match.slice(1).map((n,i)=>n===undefined?0:Number(n));
    const dt=new Date(Date.UTC(y,mo-1,d,h,mi,se));
    if(y<2000||y>2100||dt.getUTCFullYear()!==y||dt.getUTCMonth()!==mo-1||dt.getUTCDate()!==d||h>23||mi>59||se>59)return '';
    return dt.toISOString().slice(0,19);
  }
  function signature(r){return JSON.stringify([r.studentId,r.domain,r.skill,r.task,r.attempt,r.date]);}
  function number(v,fallback){return v===undefined||v===null||String(v).trim()===''?fallback:Number(v);}
  function validate(table,map,mode,existing,filename,batchSource){
    const errors=[],warnings=[],valid=[],seen=new Map(existing.map(r=>[signature(r),r])),ids=new Set(existing.filter(r=>r.recordId).map(r=>r.source+'|'+r.recordId));
    let duplicates=0;
    fields.filter(f=>f[2]).forEach(([k,l])=>{if(map[k]===undefined||map[k]<0)errors.push({row:1,message:'缺少必需列：'+l});});
    const selected=Object.values(map).filter(i=>i>=0);
    if(new Set(selected).size!==selected.length)errors.push({row:1,message:'每列只能映射到一个字段'});
    if(table.rows.length>5000)errors.push({row:1,message:'单批最多导入 5000 条记录'});
    if(errors.length)return {valid,errors,warnings,duplicates};
    if(map.task<0)warnings.push('缺少任务列，按技能名称分组。请确认同一技能的训练情境一致。');
    if(map.attempt<0)warnings.push('缺少轮次列，默认第 1 轮；复练记录建议填写轮次。');
    if(map.kind<0)warnings.push('未提供数据性质列。请确认文件包含真实记录，示例文件不得作为真实成绩。');
    table.rows.forEach((row,i)=>{
      const get=k=>map[k]>=0?row[map[k]]:undefined;
      const rowErrors=[];const domain=domainId(get('domain'));
      const id=String(get('studentId')??'').trim(); const skill=String(get('skill')??'').trim();
      const score=number(get('score'),NaN),maxScore=number(get('maxScore'),100),attempt=number(get('attempt'),1),date=dateValue(get('date'));
      const kind=String(get('kind')||'').trim().toLowerCase();
      if(!id)rowErrors.push('学号为空');if(!domain)rowErrors.push('模块须为家园共育、环境创设或一日生活');if(!skill)rowErrors.push('技能为空');
      if(!Number.isFinite(score))rowErrors.push('成绩须为数字（不能留空）');
      if(!Number.isFinite(maxScore)||maxScore<=0||score<0||score>maxScore)rowErrors.push('成绩须在 0 与满分之间，满分须大于 0');
      if(!Number.isInteger(attempt)||attempt<1)rowErrors.push('轮次须为正整数');
      if(!date)rowErrors.push('训练时间格式无效，须为 YYYY-MM-DD 或 YYYY-MM-DD HH:mm:ss');
      const generated=isBuiltinRecord({dataset:get('dataset'),recordId:get('recordId')});
      if(mode==='real' && (generated||/demo|sample|演示|示例|模拟/.test(kind)||/demo|sample|演示|示例|模拟/i.test(filename)))rowErrors.push('演示/示例记录不能进入真实数据区，请切换历史档案');
      if(id.length>60||skill.length>120||String(get('feedback')||'').length>4000)rowErrors.push('字段长度超过限制');
      const responseSeconds=number(get('responseSeconds'),null); if(responseSeconds!==null&&(!Number.isFinite(responseSeconds)||responseSeconds<0))rowErrors.push('回应秒数须为空或非负数字');
      if(rowErrors.length){errors.push({row:i+2,message:rowErrors.join('；')});return;}
      const r={id:'r-'+(typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+i),studentId:id,name:String(get('name')||id).trim(),domain,skill,task:String(get('task')||skill).trim(),score,maxScore,normalized:Math.round(score/maxScore*10000)/100,date,attempt,feedback:String(get('feedback')||''),source:String(get('source')||batchSource||'用户导入'),recordId:String(get('recordId')||''),kind:mode,filename,importedAt:new Date().toISOString(),responseSeconds,ageGroup:String(get('ageGroup')||''),supportAction:String(get('supportAction')||''),dataset:String(get('dataset')||'')};
      const sig=signature(r),prior=seen.get(sig),sourceId=r.source+'|'+r.recordId;
      if(prior){if(prior.score===r.score&&prior.maxScore===r.maxScore){duplicates++;return;}errors.push({row:i+2,message:'同一学生、任务、技能、轮次和时间存在不同成绩，请核对原始记录'});return;}
      if(r.recordId&&ids.has(sourceId)){errors.push({row:i+2,message:'来源平台与记录编号重复，请核对'});return;}
      seen.set(sig,r);if(r.recordId)ids.add(sourceId);valid.push(r);
    });
    return {valid,errors,warnings,duplicates};
  }
  function latest(records){const m=new Map(); [...records].sort((a,b)=>a.date.localeCompare(b.date)||a.attempt-b.attempt||String(a.importedAt||'').localeCompare(String(b.importedAt||''))).forEach(r=>m.set(JSON.stringify([r.domain,r.skill,r.task]),r));return [...m.values()];}
  function summary(records,studentId,rules){
    const rows=records.filter(r=>r.studentId===studentId),recent=latest(rows);
    const abilities=domains.map(d=>{const ds=recent.filter(r=>r.domain===d.id);return {...d,value:ds.length?Math.round(ds.reduce((s,r)=>s+r.normalized,0)/ds.length*10)/10:null,count:ds.length};});
    const weaknesses=recent.filter(r=>r.normalized<rules.target).sort((a,b)=>a.normalized-b.normalized);
    const total=abilities.filter(a=>a.value!==null);
    const progress=recent.map(r=>{const history=rows.filter(x=>x.domain===r.domain&&x.skill===r.skill&&x.task===r.task).sort((a,b)=>a.date.localeCompare(b.date)||a.attempt-b.attempt);return {...r,history,first:history[0]?.normalized,delta:history.length>1?r.normalized-history[0].normalized:null,improved:history.length>1&&history[0].normalized<rules.target&&r.normalized>=rules.target};});
    return {rows,recent,abilities,weaknesses,progress,average:total.length?Math.round(total.reduce((s,a)=>s+a.value,0)/total.length*10)/10:null,coverage:total.length};
  }
  function training(r){
    if(r.domain==='family' && /依据/.test(r.skill))return {title:'家长沟通 · 专业依据专项',steps:['回看原始沟通记录，标记需要解释的事实。','查找教师提供的课程依据，写出“观察事实 + 专业解释 + 下一步约定”。','在 VR 配套软件中复练同一情境，导出新一轮评价记录。'],evidence:'专业依据、解决路径的新一轮评分及教师评语'};
    if(r.domain==='environment')return {title:'分龄环创 · '+r.skill+'专项',steps:['对照课程评价量规，圈出作品中需要修改的位置。','填写目标年龄组，说明材料、操作方式和设计调整。','上传修改后的作品，请教师评分后导入或登记复评结果。'],evidence:'作品前后版本、目标年龄组、教师评价'};
    if(r.domain==='life')return {title:r.skill+' · 实操复练专项',steps:['请实训教师复核原始成绩和设备记录，确认失分项目。','按课程实训规程，在教师指导下使用智能娃娃训练。','导出同一任务的新一轮成绩，并核对轮次和训练时间。'],evidence:'同一技能、同一任务的新一轮设备成绩及教师复核'};
    return {title:r.skill+' · 沟通复练专项',steps:['回看原始记录，找出失分环节。','用“回应感受、说明事实、约定行动”的结构重写沟通提纲。','在 VR 配套软件中复练，导入同一任务的新一轮记录。'],evidence:'沟通记录、评价记录和复练成绩'};
  }
  function isSafetySkill(skill){return /安全应急|海姆立克|异物阻塞|应急处置/.test(String(skill));}
  function caseData(){
    const records=[];let n=0;
    function add(domain,skill,score,attempt,feedback){const d=domains.find(x=>x.id===domain);records.push({id:'demo-'+(++n),studentId:'20250100608',name:'林悦（演示）',domain,skill,task:d.task,score,maxScore:100,normalized:score,date:'2026-03-'+String(12+attempt).padStart(2,'0')+'T10:00:00',attempt,feedback,source:'比赛演示脚本',recordId:'DEMO-'+n,kind:'demo',filename:'内置演示数据',importedAt:'2026-03-13T10:00:00',responseSeconds:domain==='family'?3:null,ageGroup:domain==='environment'?'1–3 岁':''});}
    [['情绪识别',90,'能及时回应家长情绪，回应时长 3 秒。'],['专业依据',62,'能共情，但缺少专业依据。'],['话术选择',88,'使用共情型话术。'],['解决路径',82,'提出后续沟通约定。']].forEach(x=>add('family',...x.slice(0,2),1,x[2]));
    [['安全性',86,'设计需由教师复核材料。'],['分龄适宜性',70,'目标为 1–3 岁，互动操作需要调整。'],['互动性',76,'建议增加可操作的互动环节。'],['教育价值',84,'活动目标清晰。']].forEach(x=>add('environment',...x.slice(0,2),1,x[2]));
    [['喂养照护',92,'PPT 演示成绩。'],['拍嗝哄睡',90,'PPT 演示成绩。'],['生活组织',86,'为演示画像补充的模拟成绩。'],['安全应急',68,'PPT 演示成绩，需专项补强。']].forEach(x=>add('life',...x.slice(0,2),1,x[2]));
    return records;
  }
  function replayData(){return [74,80,85].map((score,i)=>({id:'demo-replay-'+i,studentId:'20250100608',name:'林悦（演示）',domain:'life',skill:'安全应急',task:'智能娃娃照护实训',score,maxScore:100,normalized:score,date:'2026-0'+(4+i)+'-20T10:00:00',attempt:i+2,feedback:'PPT 复练演示成绩。',source:'比赛演示脚本',recordId:'DEMO-REPLAY-'+i,kind:'demo',filename:'内置复练脚本',importedAt:'2026-06-20T10:00:00',responseSeconds:null,ageGroup:''}));}
  const growthVersion='semester-2026-spring-v1',growthStart='2026-03',growthEnd='2026-07';
  function isBuiltinRecord(r){return /^demo-\d+$|^demo-replay-|^growth-|^semester-2026-/.test(String(r.id||''))||/^two-year-simulation-v\d+$|^semester-2026-spring-v\d+$/.test(String(r.dataset||''))||/^SIM-\d{4}-\d{2}-/.test(String(r.recordId||''));}
  function semesterArchive(archive){
    if(archive.datasetVersion===growthVersion)return archive;
    return {...archive,records:[...archive.records.filter(r=>!isBuiltinRecord(r)),...demoData()],legacyRecords:(archive.legacyRecords||[]).filter(r=>!isBuiltinRecord(r)),datasetVersion:growthVersion};
  }
  function rank(value,rules){
    if(value===null||value===undefined)return {name:'待补录',className:'pending',level:0};
    if(value>=rules.excellent)return {name:'精英',className:'elite',level:3};
    if(value>=rules.target)return {name:'尖兵',className:'pioneer',level:2};
    if(value>=rules.pass)return {name:'新锐',className:'novice',level:1};
    return {name:'起步',className:'beginner',level:0};
  }
  function demoData(){
    // 确定性的情境模拟档案，不代表已发生的真实训练或实证效果。
    const anchors=[61,73,82,90,97];
    const offsets=[[4,-4,2,1],[3,-3,-1,1],[2,1,0,-4]],prior=new Map(),rows=[];
    const focus={
      '情绪识别':['识别家长焦虑并回应感受','区分感受与事实，减少机械安慰','在多轮沟通中保持共情','针对不同家长情境调整回应'],
      '专业依据':['区分观察事实与主观判断','为沟通解释补充课程依据','把专业解释转化为家长易懂的表达','完整说明依据、边界与后续约定'],
      '话术选择':['完成基础沟通句式练习','回看话术失分，修改沟通提纲','在质疑情境中使用清晰表达','综合情境中保持表达专业与自然'],
      '解决路径':['提出初步沟通约定','明确下一步观察和反馈时间','形成家园合作的行动清单','根据后续记录修订沟通安排'],
      '安全性':['列出材料与使用条件','根据教师反馈修改设计细节','完成作品安全观察清单','结合实物和使用情境复核设计'],
      '分龄适宜性':['说明目标年龄与活动目标','对照年龄特点修改操作方式','比较不同年龄组的作品方案','根据观察记录迭代分龄设计'],
      '互动性':['加入基础可操作环节','优化互动位置与活动流程','记录互动过程和教师观察点','完成综合互动情境的设计优化'],
      '教育价值':['把活动目标写入设计说明','将设计元素对应课程目标','用观察记录检验活动目标','整合作品证据完成设计反思'],
      '喂养照护':['熟悉课程任务与设备评价项','对照失分项目开展专项训练','完成同任务多轮实操复练','在教师指导下完成综合任务'],
      '拍嗝哄睡':['完成基础实训流程练习','回看评价记录并定位失分','完成同情境复练与教师反馈','完成综合照护任务的迁移练习'],
      '生活组织':['列出一日生活的观察点','改进任务安排和记录方式','统整照护情境中的活动组织','按综合任务形成完整证据记录'],
      '安全应急':['辨认课程量规中的重点项目','请教师复核失分，安排专项复练','在教师指导下完成同项目复评','复核综合情境中的实训表现']
    };
    for(let m=0;m<5;m++){
      const month=new Date(Date.UTC(2026,2+m,1)).toISOString().slice(0,7),phase=Math.min(3,m);
      domains.forEach((d,di)=>d.skills.forEach((skill,si)=>{
        const key=d.id+'|'+skill,raw=Math.round((anchors[m]+offsets[di][si]*(1-m/4*.75))*10)/10;
        const score=Math.min(99,Math.max(prior.get(key)||0,raw));prior.set(key,score);
        const day=20+di,date=month+'-'+day+'T'+String(9+di).padStart(2,'0')+':'+String(si*12).padStart(2,'0')+':00';
        const action=[['助学任务单','助教示范','基础情境演练'],['助评诊断','助学专项复练','助管跟踪'],['助教综合任务','助研复练分析','同伴互评与复评'],['助创情境拓展','助研迁移反思','助管归档']][phase].join(' + ');
        rows.push({id:'semester-'+month+'-'+di+'-'+si,studentId:'20250100608',name:'林悦',domain:d.id,skill,task:d.task,score,maxScore:100,normalized:score,date,attempt:m+1,feedback:focus[skill][phase]+'。'+(score<80?'继续按任务单补强。':score<90?'本轮达到专项目标，进入综合练习。':'本轮进入精英阶段，继续巩固迁移能力。'),source:'历史档案 · 示例数据（生成）',recordId:'SIM-'+month+'-'+di+'-'+si,kind:'demo',filename:'2026春季学期成长示例档案',importedAt:'2026-07-23T00:00:00',responseSeconds:d.id==='family'?Math.round((7.2-m*1.1+si*.15)*10)/10:null,ageGroup:d.id==='environment'?(phase%2?'3–6 岁':'1–3 岁'):'',supportAction:action,dataset:growthVersion,month});
      }));
    }
    return rows;
  }
  function growthSeries(records,studentId,rules){
    const rows=records.filter(r=>r.studentId===studentId),months=[...new Set(rows.map(r=>r.date.slice(0,7)))].sort();
    return months.map(month=>{const subset=rows.filter(r=>r.date.slice(0,7)<=month),s=summary(subset,studentId,rules),monthly=rows.filter(r=>r.date.slice(0,7)===month);return {month,value:s.average,abilities:s.abilities,rank:rank(s.coverage===3?s.average:null,rules),count:monthly.length,cumulative:subset.length,actions:[...new Set(monthly.map(r=>r.supportAction).filter(Boolean))]};});
  }
  function renameStudentId(value,previous,next){
    if(!value||typeof value!=='object')return value;
    const entries=Array.isArray(value)?value.map((v,i)=>[i,v]):Object.entries(value);
    let changed=false;
    const updated=entries.map(([key,item])=>{const result=key==='studentId'&&item===previous?next:renameStudentId(item,previous,next);if(result!==item)changed=true;return [key,result];});
    return changed?(Array.isArray(value)?updated.map(([,v])=>v):Object.fromEntries(updated)):value;
  }
  function safeURL(v){if(!v)return '';try{const u=new URL(v);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}}
  function csvCell(v){let s=String(v??'');if(/^[\s]*[=+\-@]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
  function exportCSV(records){const keys=fields.map(f=>f[0]);return '\uFEFF'+[fields.map(f=>csvCell(f[3][0])).join(','),...records.map(r=>keys.map(k=>csvCell(k==='date'?String(r.date||'').replace('T',' '):k==='maxScore'?r.maxScore:k==='kind'?r.kind:r[k])).join(','))].join('\r\n');}
  return {domains,fields,clone,domainId,parseCSV,autoMap,dateValue,signature,validate,latest,summary,training,isSafetySkill,demoData,caseData,replayData,growthSeries,growthVersion,growthStart,growthEnd,isBuiltinRecord,semesterArchive,rank,renameStudentId,safeURL,exportCSV};
});
