(async function(){
  'use strict';
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icons={
    sprout:'<path d="M12 21V11M12 14C3 14 2 4 5 5c7 0 8 5 7 9M12 11c0-8 10-9 8-4-2 5-6 5-8 4"/>',
    home:'<path d="m3 10 9-7 9 7M5 9v12h14V9M10 21v-7h4v7"/>',
    heart:'<path d="M20 5c-3-3-6-1-8 1-2-2-5-4-8-1-5 5 2 11 8 16 6-5 13-11 8-16Z"/>',
    chat:'<path d="M21 11a8 8 0 0 1-8 8H5l-3 3V11a9 9 0 0 1 19 0Z"/><path d="M7 10h10M7 14h6"/>',
    book:'<path d="M12 5C8 2 3 4 3 4v16s5-2 9 1c4-3 9-1 9-1V4s-5-2-9 1v16"/>',
    file:'<path d="M14 2H5v20h14V7l-5-5v5h5M8 12h8M8 16h6"/>',
    globe:'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
    news:'<path d="M4 3h16v18H4zM8 7h8M8 11h8M8 15h3M14 15h2M8 18h8"/>',
    blocks:'<rect x="3" y="12" width="8" height="9" rx="1"/><rect x="13" y="12" width="8" height="9" rx="1"/><path d="m8 3 5 7H3l5-7ZM17 3v5M14 6h6"/>',
    chart:'<path d="M3 3v18h18M7 16l4-5 4 2 5-8"/><circle cx="20" cy="5" r="1"/>',
    upload:'<path d="M12 16V3m-5 5 5-5 5 5M3 15v6h18v-6"/>',
    settings:'<path d="m9 3 1-2h4l1 2 3 2 2 1 2 4-1 2-1 3v3l-4 3-2-1h-4l-2 1-4-3v-3l-1-3-1-2 2-4 2-1 3-2Z"/><circle cx="12" cy="12" r="4"/>',
    play:'<path d="m8 4 13 8-13 8V4Z"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',
    bolt:'<path d="m13 2-9 12h7l-1 8 10-12h-7l1-8Z"/>',
    target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 6v7l4 2"/>',
    user:'<circle cx="12" cy="8" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
    warning:'<path d="m12 3 10 18H2L12 3ZM12 9v5M12 17v1"/>',
    layers:'<path d="m12 3 10 5-10 5L2 8l10-5ZM2 12l10 5 10-5M2 16l10 5 10-5"/>',
    search:'<circle cx="10" cy="10" r="7"/><path d="m15 15 6 6"/>',
    portal:'<rect x="5" y="5" width="14" height="14" rx="3"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 1v4m6-4v4m-6 14v4m6-4v4M1 9h4m-4 6h4m14-6h4m-4 6h4"/>',
    download:'<path d="M12 3v13m-5-5 5 5 5-5M3 15v6h18v-6"/>'
  };
  const ico=n=>'<svg class="ico" viewBox="0 0 24 24" aria-hidden="true">'+(icons[n]||icons.book)+'</svg>';
  const menus=[
    ['ethics','师德师风修养','Professional Ethics','heart'],['policy','教育政策法规','Education Policies','file'],['news','行业动态资讯','Industry News','news'],['smart','智慧班管之路','Smart Class Management','layers'],['growth','教师专业成长','Professional Development','book'],['global','国际化新视野','A Global Perspective','globe']
  ];
  const assists=[['learn','助学','Student aid'],['research','助研','Research assistant'],['teach','助教','Teaching assistant'],['evaluate','助评','Assist in evaluation'],['manage','助管','Assistant manager'],['create','助创','Assist in innovation']];
  const lessons={
    ethics:[['尊重儿童的观察记录','用事实描述行为，区分观察、解释和评价。',['把“孩子不听话”改写成一次可观察的行为记录。','记录情境、行为和教师回应，避免给儿童贴标签。','完成课程讨论：向家长反馈时，哪些内容需要保护隐私？']],['家园沟通的职业边界','在焦虑、质疑等情境中练习有温度、有依据的沟通。',['确认家长的感受，再说明已核实的事实。','列出尚需了解的信息和下一次沟通约定。','进入家园共育实训，提交教师评价记录。']]],
    policy:[['政策学习资料夹','离线版提供学习任务框架。请由教师补充经核实的政策原文与版本。',['在平台配置中添加官方资料名称和链接。','阅读原文，摘录与班级管理相关的条款并记录版本。','结合课程案例说明适用情境，提交教师讨论。']],['政策与情境对照练习','围绕儿童权益、信息保护与家园协作建立阅读卡片。',['选择一条教师提供的政策资料。','记录发布日期、适用对象和原文位置。','用一段具体情境说明如何落实，避免脱离原文解释。']]],
    news:[['行业观察笔记','这里是离线学习素材区。资讯由教师手动维护，不生成实时热搜。',['选取一条有明确日期和出处的行业资料。','区分事实报道、机构宣传和个人观点。','写出对班级管理课程的一项启发。']],['数字工具体验记录','记录 VR、环创软件或智能娃娃的学习使用体验。',['说明工具用于什么任务，产生什么记录。','找出对教学有用的过程证据。','用实际导出的数据验证学习效果。']]],
    growth:[['个人复练计划','根据当前画像，把薄弱技能转化为下一次训练任务。',['查看三域能力画像与原始失分记录。','选择一个需要补强的技能，添加复练任务。','在外部平台训练后导入新成绩，比较同一任务的前后变化。']],['教学反思札记','围绕一项训练记录完成教学反思。',['选取一条原始记录，说明训练目标。','写出评分证据与学生回应，区分数据与推测。','提出教学调整，并在下一次实训中验证。']]],
    global:[['国际案例比较','教师可在资料夹补充国际学前教育案例与出处。',['记录案例的国家、机构、年龄组和资料日期。','比较环境设计、家园协作与本地情境。','提出可验证的课堂尝试，说明条件和限制。']],['双语家园沟通练习','用清晰简短的双语表达说明观察事实与后续约定。',['先用中文完成事实记录与沟通提纲。','选择教师提供的双语表达资料。','进行角色演练，提交同伴与教师反馈。']]]
  };
  const storePrefix='yitong.v1.';let volatile=false;const memory={};
  function read(k,def){try{const v=localStorage.getItem(storePrefix+k);return v?JSON.parse(v):YT.clone(def);}catch{volatile=true;return memory[k]??YT.clone(def);}}
  function write(k,v){try{localStorage.setItem(storePrefix+k,JSON.stringify(v));}catch{volatile=true;memory[k]=v;throw Error('浏览器无法保存数据或空间不足。请先导出备份，检查浏览器存储设置。');}}
  let auth=read('session',null),mode=read('mode','demo'),page='home',domain='family',student='',selectedAssist='learn',chat=[],tour=null,importState=null,lessonOpen='',chartSelection='',viewURL=[];
  let checkpoint=read('checkpoint','2026-07'),growthPlayer=null;
  let motion=read('motion',!window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const ART=window.YT_ART;
  let config=read('config',window.YT_CONFIG),accounts=read('accounts',[]);
  config={...YT.clone(window.YT_CONFIG),...config,platforms:{...window.YT_CONFIG.platforms,...config.platforms},rules:{...window.YT_CONFIG.rules,...config.rules}};
  function cleanDollPlatform(c){const p=c.platforms?.life;if(p)['name','note'].forEach(k=>{if(typeof p[k]==='string')p[k]=p[k].replace(/\u91d1\u804c\u4f1f\u4e1a\s*(?=智能娃娃)/g,'');});return c;}
  config=cleanDollPlatform(config);
  if(!['demo','real'].includes(mode))mode='demo';
  config.version=window.YT_CONFIG.version;
  config.xiaoguan={endpoint:config.xiaoguan?.endpoint||'',model:config.xiaoguan?.model||''};
  if(auth?.id==='demo')auth={...auth,name:'林悦'};
  let demo=read('demo',{records:YT.demoData(),works:[],tasks:[],notes:{},batches:[],datasetVersion:YT.growthVersion});
  if(demo.datasetVersion!==YT.growthVersion){
    demo=YT.semesterArchive(demo);
    checkpoint=YT.growthEnd;
    try{write('demo',demo);}catch{volatile=true;}
  }
  let real={records:[],works:[],tasks:[],notes:{},batches:[]};
  const realKey=()=> 'real.'+(auth?.id||'guest');
  function loadReal(){real=read(realKey(),{records:[],works:[],tasks:[],notes:{},batches:[]});}
  loadReal();
  function db(){return mode==='demo'?demo:real;}
  function persist(next){if(mode==='demo')next=YT.semesterArchive(next);const key=mode==='demo'?'demo':realKey();write(key,next);if(mode==='demo')demo=next;else real=next;}
  function mutate(fn){const next=YT.clone(db());fn(next);persist(next);}
  const isTeacher=()=>auth?.role==='teacher';
  const uploadEntry=(text='上传作品',cls='outline')=>isTeacher()?'':button(text,'upload-work',cls);
  function students(){const m=new Map();db().records.forEach(r=>m.set(r.studentId,r.name));db().works.forEach(w=>m.set(w.studentId,w.name));if(!m.size && mode==='demo')m.set('2023001','林悦');return [...m].map(([id,name])=>({id,name}));}
  function selectedStudent(){const list=students();if(!list.some(x=>x.id===student))student=mode==='demo'&&list.some(x=>x.id==='2023001')?'2023001':list.some(x=>x.id===auth?.studentId)?auth.studentId:list[0]?.id||'';return student;}
  function periods(){return [...new Set(db().records.filter(r=>r.studentId===selectedStudent()).map(r=>r.date.slice(0,7)))].sort();}
  function data(){
    const all=db().records,sid=selectedStudent(),months=periods();
    if(mode==='demo'&&!months.includes(checkpoint))checkpoint=months.at(-1)||'2026-07';
    const rows=mode==='demo'?all.filter(r=>r.date.slice(0,7)<=checkpoint):all;
    const baseline=YT.summary(all.filter(r=>r.date.slice(0,7)<=months[0]),sid,config.rules).abilities;
    return {...YT.summary(rows,sid,config.rules),baseline};
  }
  function badge(){return '<span class="pill '+mode+'">'+(mode==='demo'?'示例数据':'实训记录')+'</span>';}
  function score(v){return v===null||v===undefined?'待补录':Number(v).toFixed(1).replace(/\.0$/,'');}
  function scoreBand(v){if(v<config.rules.pass)return '低于合格参考';if(v<config.rules.target)return '待补强';if(v<config.rules.excellent)return '达到目标';return '优秀参考';}
  function toast(t){$('#toast').innerHTML='<div class="toast">'+esc(t)+'</div>';clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('#toast').innerHTML='',4000);}
  function button(text,action,cls='secondary',extra=''){return '<button class="btn '+cls+'" data-action="'+action+'" '+extra+'>'+text+'</button>';}
  function closeModal(){ $('#overlay').innerHTML='';importState=null; }
  function modal(title,body,actions='',wide=false){$('#overlay').innerHTML='<div class="modal-backdrop"><section class="modal '+(wide?'wide':'')+'" role="dialog" aria-modal="true" aria-label="'+esc(title)+'"><div class="modal-head"><h2>'+esc(title)+'</h2><button class="close-btn" data-action="close" aria-label="关闭">×</button></div><div class="modal-body">'+body+'</div><div class="modal-actions">'+actions+'</div></section></div>';$('#overlay').querySelector('input,select,textarea,button')?.focus();}
  function download(name,content,type='text/plain;charset=utf-8'){const blob=content instanceof Blob?content:new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function toPage(p,d){if(p!=='assistant')chat=[];page=p;if(d)domain=d;lessonOpen='';render();window.scrollTo({top:0,behavior:'smooth'});}
  function modeBanner(){
    const s=data(),months=periods(),r=YT.rank(s.coverage===3?s.average:null,config.rules),span=months.length?months[0].replace('-','.')+'—'+months.at(-1).replace('-','.'):'';
    return '<div class="mode-banner"><div class="flex wrap">'+badge()+'<span class="rank-chip '+r.className+'">'+r.name+'</span><span class="muted">'+(mode==='demo'?span+' · 历史档案':'按实际训练记录生成画像')+'</span>'+button('档案说明','archive-info','archive-link')+'</div><div class="flex wrap mode-selects">'+(mode==='demo'?'<select class="period-select" id="checkpoint-select" aria-label="回看训练月份">'+months.map(m=>'<option value="'+m+'" '+(m===checkpoint?'selected':'')+'>'+m.replace('-',' 年 ')+' 月</option>').join('')+'</select>':'')+'<select class="student-select" id="student-select" aria-label="选择学生">'+(students().length?students().map(st=>'<option value="'+esc(st.id)+'" '+(st.id===selectedStudent()?'selected':'')+'>'+esc(st.name)+' · '+esc(st.id)+'</option>').join(''):'<option value="">等待成绩录入</option>')+'</select></div></div>';
  }
  function pageHead(title,desc,actions=''){return '<div class="page-head"><div><h1>'+title+'</h1><p>'+desc+'</p></div><div class="flex wrap">'+actions+'</div></div>';}
  function studentDisplay(){const s=students().find(x=>x.id===selectedStudent());return s?esc(s.name)+' · '+esc(s.id):'暂无学生';}
  function login(register=false,type='student'){
    $('#app').innerHTML='<main class="login-page"><div class="login-left"><div class="brand-crop"><img src="assets/login-reference.png" alt="益童成长 YI TONG GROWTH"></div><div class="login-kicker">六助护航，让成长有方向</div><div class="login-panel '+(register?'register-panel':'')+'">'+(register?'<h2>创建学习账号</h2>':'')+''+(register?'':'<div class="login-tabs"><button data-action="login-type" data-type="student" class="'+(type==='student'?'active':'')+'">学号登录</button><button data-action="login-type" data-type="phone" class="'+(type==='phone'?'active':'')+'">手机号登录</button></div>')+'<form id="auth-form" data-register="'+register+'" data-type="'+type+'">'+(register?'<div class="rowform"><div class="field"><label for="reg-name">姓名</label><input id="reg-name" name="name" autocomplete="name" required maxlength="30"></div><div class="field"><label for="reg-student">学号</label><input id="reg-student" name="studentId" required maxlength="30" pattern="[A-Za-z0-9_-]{3,30}"></div></div><div class="field"><label for="reg-phone">手机号码</label><input id="reg-phone" name="phone" inputmode="tel" autocomplete="tel" pattern="1[0-9]{10}" maxlength="11" required placeholder="11 位手机号码"></div>':'<div class="field"><label for="login-identity">'+(type==='student'?'学号':'手机号码')+'</label><input id="login-identity" name="identity" autocomplete="username" '+(type==='phone'?'inputmode="tel" maxlength="11"':'maxlength="30"')+' required placeholder="'+(type==='student'?'请输入学号 / 教师工号':'请输入手机号码')+'"></div>')+'<div class="field"><label for="auth-password">密码</label><input id="auth-password" name="password" type="password" autocomplete="'+(register?'new-password':'current-password')+'" required minlength="8" maxlength="100" placeholder="'+(register?'至少 8 位':'请输入密码')+'"></div>'+(register?'<div class="field"><label for="confirm-password">确认密码</label><input id="confirm-password" name="confirm" type="password" required minlength="8" autocomplete="new-password"></div>':'')+'<button class="btn" type="submit">'+(register?'注册并进入':'登 录 <small>Login</small>')+'</button><div id="auth-error" class="error" role="alert"></div></form><div class="login-links"><button class="linkbtn" data-action="'+(register?'show-login':'show-register')+'">'+(register?'已有账号，去登录':'注册账号')+'</button></div></div><div class="login-foot">六助护航 · 三域协同成长<br>支持学号 / 教师工号 / 手机号码登录</div></div><aside class="login-assists">'+assists.map(a=>'<button class="login-assist" data-action="login-assist" data-assist="'+a[0]+'">'+XiaoGuan.decor()+'<b>'+a[1]+'</b><span>'+a[2]+'</span></button>').join('')+'</aside><div class="login-ground">'+ART.garden('login-garden')+'</div><div class="login-sky-cloud">'+ART.cloud()+'</div></main>';
  }
  async function hashPassword(password,salt){if(!crypto.subtle)throw Error('当前浏览器不支持本地账号加密，请使用新版 Edge 或 Chrome。');const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);const v=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(salt),iterations:120000,hash:'SHA-256'},key,256);return Array.from(new Uint8Array(v)).map(n=>n.toString(16).padStart(2,'0')).join('');}
  async function authenticate(form){
    const f=Object.fromEntries(new FormData(form)),register=form.dataset.register==='true',error=$('#auth-error'),submit=form.querySelector('[type=submit]');submit.disabled=true;error.textContent='';
    try{
      if(register){
        if(!f.name.trim())throw Error('请填写姓名');if(!/^[A-Za-z0-9_-]{3,30}$/.test(f.studentId))throw Error('学号须为 3–30 位字母、数字、下划线或短横线');
        if(!/^1\d{10}$/.test(f.phone))throw Error('请输入 11 位手机号码');if(f.password!==f.confirm)throw Error('两次密码不一致');
        if(accounts.some(a=>a.studentId===f.studentId||a.phone===f.phone)||['2023001','T2026001'].includes(f.studentId)||['13800000000','13900000000'].includes(f.phone))throw Error('学号或手机号已存在（包含预置账号）');
        const salt=crypto.randomUUID(),account={id:crypto.randomUUID(),name:f.name.trim(),studentId:f.studentId,phone:f.phone,role:'student',salt,hash:await hashPassword(f.password,salt)};
        write('accounts',[...accounts,account]);accounts=[...accounts,account];auth={id:account.id,name:account.name,studentId:account.studentId,role:'student'};mode='real';
      }else{
        const identity=f.identity.trim(),isDemo=(form.dataset.type==='student'?identity==='2023001':identity==='13800000000');
        if(isDemo&&f.password==='Yitong123'){auth={id:'demo',name:'林悦',studentId:'2023001',role:'student'};mode='demo';checkpoint='2026-07';}
        else if((form.dataset.type==='student'?identity==='T2026001':identity==='13900000000')&&f.password==='Teacher123'){auth={id:'teacher',name:'高老师',studentId:'T2026001',role:'teacher'};mode='real';}
        else{const a=accounts.find(a=>form.dataset.type==='student'?a.studentId===identity:a.phone===identity);if(!a||await hashPassword(f.password,a.salt)!==a.hash)throw Error('学号/手机号或密码不正确');auth={id:a.id,name:a.name,studentId:a.studentId,role:a.role||'student'};mode='real';}
      }
      write('session',auth);write('mode',mode);loadReal();page=isTeacher()?'teacher':'home';student='';render();
    }catch(e){error.textContent=e.message;}finally{submit.disabled=false;}
  }
  function render(){
    viewURL.forEach(u=>URL.revokeObjectURL(u));viewURL=[];
    document.documentElement.classList.toggle('motion-off',!motion);
    if(!auth){login();return;}
    selectedStudent();
    if(page==='teacher'&&!isTeacher())page='home';
    document.documentElement.classList.toggle('motion-off',!motion);
    const content=page==='home'?home():page==='smart'?smart():page==='portrait'?portrait():page==='data'?dataCenter():page==='settings'?settings():page==='competition'?competition():page==='assistant'?assistant():page==='teacher'?teacherPage():page==='xiaoguan'?'<div id="xg-root">'+XiaoGuan.page(config)+'</div>':learning(page);
    $('#app').innerHTML='<header class="topbar"><div class="brand" data-action="nav" data-page="home" tabindex="0" role="button" aria-label="返回首页"><span class="brand-icon"><img src="assets/yitong-icon.png" alt="益"></span><div><div class="brand-name"><em>益童</em>成长</div><div class="brand-sub">YI TONG GROWTH</div></div></div><div class="top-actions"><span class="connection"><i class="dot"></i> 本地运行</span><div class="segmented" aria-label="数据模式"><button data-action="mode" data-mode="demo" class="'+(mode==='demo'?'active':'')+'">历史档案</button><button data-action="mode" data-mode="real" class="'+(mode==='real'?'active':'')+'">成绩录入</button></div>'+button(ico('play')+'成长汇报','tour-start','gold')+'<span class="avatar">'+esc(auth.name.slice(0,1))+'</span><span class="pill role-badge">'+(isTeacher()?'教师':'学生')+'</span><span class="user-name small muted">'+esc(auth.name)+'</span><button class="linkbtn small" data-action="logout">退出</button></div></header>'+(tour?tourbar():'')+'<div class="shell"><nav class="sidebar" aria-label="一级菜单"><div class="sidebar-label">学习与成长</div>'+menus.map(m=>'<button class="nav-button '+(page===m[0]?'active':'')+'" data-action="nav" data-page="'+m[0]+'">'+ico(m[3])+'<span><b>'+m[1]+'</b><small>'+m[2]+'</small></span></button>'+(m[0]==='smart'&&page==='smart'?'<div class="subnav">'+YT.domains.map(d=>'<button class="'+(domain===d.id?'active':'')+'" data-action="domain" data-domain="'+d.id+'">'+d.name+'</button>').join('')+'</div>':'')).join('')+'<div class="side-tools">'+[...(isTeacher()?[['teacher','教师评价','check']]:[]),['xiaoguan','小管 · 课程伙伴','chat'],['home','成长首页','home'],['portrait','能力画像','chart'],['data','数据与作品','upload'],['competition','5 分钟成长汇报','clock'],['settings','平台配置','settings']].map(m=>'<button class="side-tool '+(page===m[0]?'active':'')+'" data-action="nav" data-page="'+m[0]+'">'+ico(m[2])+m[1]+'</button>').join('')+'</div><div class="side-foot">六助护航 · 三域贯通<br>成长档案 v'+esc(config.version)+'<br><a href="运行说明.html" target="_blank" rel="noopener">运行说明</a></div><div class="sidebar-flower" aria-hidden="true">'+ART.flower('#e7c88d')+'</div></nav><main class="main"><div class="breadcrumb">成长空间 <span>›</span> '+esc(page==='smart'?'智慧班管之路 / '+YT.domains.find(d=>d.id===domain).name:({home:'首页',portrait:'能力画像',data:'数据与作品',settings:'平台配置',competition:'比赛展示',assistant:'六助工作台',teacher:'教师评价与打分',xiaoguan:'小管 · 课程伙伴'}[page]||menus.find(m=>m[0]===page)?.[1]||''))+'</div>'+content+(volatile?'<p class="note warn section-gap">浏览器本地存储不可用，请立即导出数据备份；刷新可能丢失未保存记录。</p>':'')+'</main><aside class="assist-rail" aria-label="六助"><div class="assist-label">六 助 护 航</div>'+assists.map(a=>'<button class="assist-btn '+(page==='assistant'&&selectedAssist===a[0]?'active':'')+'" data-action="assist" data-assist="'+a[0]+'">'+XiaoGuan.decor()+'<b>'+a[1]+'</b><small>'+a[2]+'</small></button>').join('')+'<button class="xiaoguan-link" data-action="nav" data-page="xiaoguan" aria-label="打开小管课程伙伴">'+XiaoGuan.panda()+'<span>小管<small>课程伙伴</small></span></button></aside></div>';
    if(['smart','data','teacher'].includes(page))loadWorkImages();
  }
  function radar(s){
    const cx=180,cy=122,r=84,angles=[-Math.PI/2,Math.PI/6,5*Math.PI/6],pt=(v,i)=>[cx+Math.cos(angles[i])*r*v/100,cy+Math.sin(angles[i])*r*v/100];
    const poly=v=>angles.map((_,i)=>pt(v,i).join(',')).join(' '),target=config.rules.target;
    let out='<svg class="radar-svg" viewBox="0 0 360 260" role="img" aria-label="三域能力雷达图：'+esc(s.abilities.map(a=>a.ability+' '+score(a.value)).join('，'))+'">';
    [20,40,60,80,100].forEach(v=>{out+='<polygon points="'+poly(v)+'" fill="none" stroke="#e0edf3" stroke-width="1"/>';});
    angles.forEach((_,i)=>{const p=pt(100,i);out+='<line x1="'+cx+'" y1="'+cy+'" x2="'+p[0]+'" y2="'+p[1]+'" stroke="#e4eff4"/>';});
    if(s.baseline?.every(a=>a.value!==null))out+='<polygon points="'+s.baseline.map((a,i)=>pt(a.value??0,i).join(',')).join(' ')+'" fill="#b4cad915" stroke="#9db7c6" stroke-dasharray="3 3"/>';
    out+='<polygon points="'+poly(target)+'" fill="none" stroke="#9fc6d8" stroke-dasharray="4 4"/>';
    if(s.coverage===3)out+='<polygon class="radar-area" points="'+s.abilities.map((a,i)=>pt(a.value,i).join(',')).join(' ')+'" fill="#a2cfb64a" stroke="#7cb297" stroke-width="2"/>';
    out+='<g class="radar-sparkle" fill="#e5c36b"><path d="m295 54 3 6 7 2-7 2-3 6-2-6-7-2 7-2z"/><path d="m63 54 2 4 5 2-5 1-2 5-2-5-5-1 5-2z"/></g>';
    s.abilities.forEach((a,i)=>{const p=pt(a.value??0,i);if(a.value!==null)out+='<circle class="radar-point" cx="'+p[0]+'" cy="'+p[1]+'" r="4" fill="'+(a.value<target?'#d96565':a.color)+'"/>';const labels=[[180,18,'middle'],[283,190,'middle'],[76,190,'middle']][i];out+='<text x="'+labels[0]+'" y="'+labels[1]+'" text-anchor="'+labels[2]+'">'+a.ability+'</text><text x="'+labels[0]+'" y="'+(labels[1]+18)+'" text-anchor="middle" style="font-weight:bold;fill:'+(a.value!==null&&a.value<target?'#cc6565':a.color)+'">'+score(a.value)+(a.value===null?'':' 分')+'</text>';});
    out+='<text x="180" y="236" text-anchor="middle" style="font-size:10px">浅灰：初训画像　虚线：目标 '+target+' 分'+(s.coverage<3?'　尚有待补录领域':'')+'</text></svg>';
    return out;
  }
  function weaknessList(s,limit=4){
    if(!s.recent.length)return '<div class="empty">'+ico('target')+'<p>导入记录后生成短板诊断</p>'+button('导入训练记录','open-import')+'</div>';
    if(!s.weaknesses.length)return '<div class="empty">'+ico('check')+'<p>本阶段技能均达到当前目标</p><small>继续巩固，并开展综合情境迁移练习。</small></div>';
    return s.weaknesses.slice(0,limit).map(r=>'<div class="weakness"><div class="weakness-icon">'+ico(/安全应急/.test(r.skill)?'warning':'target')+'</div><div style="min-width:0"><h3>'+esc(r.skill)+' <span class="pill '+(r.normalized<config.rules.pass?'bad':'warn')+'">'+score(r.normalized)+' 分 · '+scoreBand(r.normalized)+'</span></h3><p>'+esc(YT.domains.find(d=>d.id===r.domain).name)+' · '+esc(r.feedback||'低于目标 '+config.rules.target+' 分，建议复练')+'</p></div>'+button('专项复练','plan','tiny secondary','data-id="'+esc(r.id)+'"')+'</div>').join('');
  }
  function growthOverview(s){
    const series=YT.growthSeries(db().records,selectedStudent(),config.rules);
    if(series.length<2)return '';
    const heading=mode==='demo'?'从新锐到精英的成长蜕变':'训练记录与阶段成长';
    const first=series[0],last=series.at(-1),current=mode==='demo'?series.find(x=>x.month===checkpoint)||last:last;
    const width=820,height=200,left=40,right=18,top=23,bottom=35,floor=mode==='demo'&&series.every(m=>m.abilities.every(a=>a.value===null||a.value>=50))?50:0,x=i=>left+(width-left-right)*i/(series.length-1),y=v=>height-bottom-(height-bottom-top)*(v-floor)/(100-floor);
    const colors=YT.domains.map(d=>d.color),labels=series.length<=8?1:Math.ceil(series.length/6);
    let chart='<svg class="journey-chart" viewBox="0 0 '+width+' '+height+'" role="img" aria-label="三域成长曲线，初训 '+first.value+' 分，最新 '+last.value+' 分">';
    (floor===50?[50,60,70,80,90,100]:[0,20,40,60,80,100]).forEach(v=>chart+='<line x1="'+left+'" y1="'+y(v)+'" x2="'+(width-right)+'" y2="'+y(v)+'" stroke="'+(v===80?'#f0d099':'#e3edf3')+'" stroke-dasharray="'+(v===80?'4 4':'0')+'"/><text x="'+(left-9)+'" y="'+(y(v)+4)+'" text-anchor="end">'+v+'</text>');
    YT.domains.forEach((d,di)=>{let points=series.map((m,i)=>m.abilities[di].value===null?null:x(i)+','+y(m.abilities[di].value)).filter(Boolean);chart+='<polyline class="draw-line" pathLength="1" points="'+points.join(' ')+'" stroke="'+colors[di]+'" fill="none" stroke-width="2.3"/>';});
    series.forEach((m,i)=>{if(i%labels===0||i===series.length-1)chart+='<text x="'+x(i)+'" y="'+(height-11)+'" text-anchor="middle">'+m.month.replace('-','.')+'</text>';});
    const ci=series.indexOf(current);chart+='<line x1="'+x(ci)+'" y1="'+top+'" x2="'+x(ci)+'" y2="'+(height-bottom)+'" stroke="#8cabbc" stroke-dasharray="3 3"/><circle cx="'+x(ci)+'" cy="'+y(current.value)+'" r="5" fill="#12618c" stroke="white" stroke-width="2"/>';
    chart+='</svg>';
    const milestones=['新锐','尖兵','精英'].map(name=>({name,row:series.find(m=>m.rank.name===name)}));
    const index=series.indexOf(current),phase=Math.min(3,index),action=mode==='demo'?['助学任务准备与基础情境演练','助评定位短板与专项复练','助教综合任务与同伴复评','助创情境拓展与迁移应用'][phase]:(current.actions.join(' · ')||'当前阶段训练记录汇总');
    return '<section class="card growth-overview section-gap"><div class="growth-heading"><div><span class="eyebrow">GROWTH PORTFOLIO</span><h2>'+heading+'</h2><p class="small muted">'+esc(first.month.replace('-','.'))+' — '+esc(last.month.replace('-','.'))+' · '+series.length+' 个训练月 · '+db().records.filter(r=>r.studentId===student).length+' 条训练记录</p></div><div class="growth-current"><span class="rank-chip '+current.rank.className+'">'+current.rank.name+'</span><b>'+score(current.value)+'<small> / 100</small></b><span class="small muted">'+current.month.replace('-','.')+' 阶段能力</span></div></div><div class="journey-legend">'+YT.domains.map(d=>'<span><i style="background:'+d.color+'"></i>'+d.ability+'</span>').join('')+'</div>'+chart+'<div class="growth-milestones">'+milestones.map(m=>'<div class="growth-milestone '+(m.row&&m.row.month<=current.month?'reached':'')+'"><span class="rank-chip '+YT.rank(m.row?.value,config.rules).className+'">'+m.name+'</span><b>'+score(m.row?.value)+'</b><small>'+(m.row?m.row.month.replace('-','.'):'目标阶段')+'</small></div>').join('')+'</div><div class="growth-action"><div>'+ico('bolt')+' <b>'+action+'</b><small> 阶段回看 '+esc(current.month)+' · 记录可追溯</small></div>'+(mode==='demo'?'<div class="flex">'+button(growthPlayer?'暂停回放':'回放成长历程','growth-play','tiny secondary')+button('下一成长阶段','growth-next','tiny outline')+'</div>':'')+'</div><div class="small muted growth-rule">成长阶梯：新锐 '+config.rules.pass+' 至低于 '+config.rules.target+'，尖兵 '+config.rules.target+' 至低于 '+config.rules.excellent+'，精英 '+config.rules.excellent+'–100。'+(mode==='demo'?'历史档案使用示例数据。':'统计依据为导入记录。')+'</div></section>';
  }
  function home(){
    const s=data();
    return '<section class="hero"><div><span class="eyebrow">GROW A LITTLE · EVERY DAY</span><h1>每一朵花，都有自己的花期</h1><p>你好呀，'+esc(auth.name)+'。把分散的训练记录，汇成看得见的成长。</p></div>'+ART.garden('hero-garden')+'</section>'+modeBanner()+growthOverview(s)+'<div class="section-title"><h2 style="margin:0">智慧班管之路</h2><span class="small muted">三域实训，同一张成长画像</span></div><div class="three">'+YT.domains.map((d,i)=>{const a=s.abilities[i];return '<article class="card domain-card" style="--domain-color:'+d.color+'"><span class="domain-number">0'+(i+1)+'</span><div class="domain-icon">'+ico(d.icon)+'</div><div><h3>'+d.name+'</h3><span class="small muted">'+d.ability+'</span></div><p>'+esc(config.platforms[d.id].note)+'</p><div class="domain-mini">最新任务均分 <b style="color:'+d.color+'">'+score(a.value)+(a.value===null?'':' 分')+'</b></div><div class="domain-corner" aria-hidden="true">'+ART.flower(['#bddbd0','#dec8df','#f4d493'][i],i)+'</div>'+button('进入实训 '+ico('arrow'),'enter-domain','outline','data-domain="'+d.id+'"')+'</article>';}).join('')+'</div><div class="dash-grid"><section class="card"><div class="card-head"><h2>三域能力画像</h2>'+button('查看详情','nav','tiny secondary','data-page="portrait"')+'</div><div class="small muted">'+studentDisplay()+'</div>'+radar(s)+'<div class="metric-list"><div><b>'+s.rows.length+'</b><span>训练记录</span></div><div><b>'+s.coverage+' / 3</b><span>已采集领域</span></div><div><b style="color:#c78d4c">'+s.weaknesses.length+'</b><span>待补强技能任务</span></div></div></section><section class="card"><div class="card-head"><h2>今日补强建议</h2><span class="pill">助评 + 助学</span></div>'+weaknessList(s,3)+'<div class="divider"></div><div class="card-head" style="margin-bottom:5px"><h3>学习轨迹</h3><span class="small muted">本地记录</span></div>'+s.rows.slice(-2).reverse().map(r=>'<div class="activity"><span class="activity-dot"></span><div><p>'+esc(r.skill)+' · 第 '+r.attempt+' 轮 · '+score(r.normalized)+' 分</p><small>'+esc(r.date.replace('T',' '))+'　'+esc(r.supportAction||r.task)+'</small></div></div>').join('')+(s.rows.length?'':'<p class="small muted">暂无训练记录</p>')+'</section></div><div class="path-strip">'+['派任务','调工具','采数据','做诊断','建画像','推补强'].map((v,i)=>'<b><span>0'+(i+1)+'</span> '+v+'</b>').join('')+'</div>';
  }
  function smart(){
    const d=YT.domains.find(d=>d.id===domain),p=config.platforms[domain],s=data(),rows=s.rows.filter(r=>r.domain===domain),recent=s.recent.filter(r=>r.domain===domain);
    return pageHead(d.name,'智慧班管之路下的二级实训模块',button(ico('upload')+'导入记录','open-import')+(domain==='environment'?uploadEntry():'') )+modeBanner()+'<div class="domain-tabs">'+YT.domains.map(d=>'<button class="'+(domain===d.id?'active':'')+'" data-action="domain" data-domain="'+d.id+'">'+d.name+'</button>').join('')+'</div><section class="card"><div class="platform-card">'+ico(d.icon)+'<div><h3>'+esc(p.name)+'</h3><p>'+esc(p.note)+'</p><span class="small muted">独立软件实训 · 文件记录回流</span><p class="campus-note">因版权限制，配套平台仅限校园网内使用</p></div>'+(p.url?button('<span class="portal-icon">'+ico('portal')+'</span> 接入平台','platform','portal-btn','data-domain="'+d.id+'"'):button('<span class="portal-icon">'+ico('portal')+'</span> 接入平台','platform-help','portal-btn','data-domain="'+d.id+'"'))+'</div>'+(domain==='environment'?'<div class="xg-entry"><div class="xg-entry-panda">'+XiaoGuan.panda()+'</div><div><h3>和课程伙伴小管一起讨论</h3><p>交流课程任务与作品图片，讨论托幼一体的设计改进。</p></div>'+button('请小管看看','nav','secondary','data-page="xiaoguan"')+'</div>':'')+'<div class="two section-gap"><div><h3>本次训练任务</h3><p class="small muted">'+esc(d.task)+'。通过训练记录完成诊断，再安排同一任务复练。</p>'+[['任务准备','对照课程任务书，确认训练情境、评分标准和学生学号。'],['外部实训',domain==='family'?'使用 VR 眼镜及独立配套软件完成沟通演练。':domain==='environment'?'使用环创软件完成设计，保存作品并填写目标年龄组。':'在实训教师指导下，使用智能娃娃及配套平台完成训练。'],['数据回流',domain==='environment'?'学生提交作品，教师登录独立评价区批阅；也可导入成绩文件。':'从配套平台导出成绩或过程记录，按模板映射后导入。']].map((x,i)=>'<div class="step"><span class="step-num">'+(i+1)+'</span><div><b>'+x[0]+'</b><br><span class="muted">'+x[1]+'</span></div></div>').join('')+'</div><div><h3>能力观察点</h3><div class="skill-grid">'+d.skills.map(skill=>{const r=recent.filter(r=>r.skill===skill);const v=r.length?Math.round(r.reduce((n,x)=>n+x.normalized,0)/r.length*10)/10:null;return '<div class="skill-card"><div class="flex between"><b class="small">'+skill+'</b><span class="score '+(v!==null&&v<config.rules.target?'bad':'')+'">'+score(v)+'</span></div><p>'+(v===null?'等待导入或教师评价':v<config.rules.target?'建议专项复练':'已达到当前目标')+'</p></div>';}).join('')+'</div></div></div></section><section class="card section-gap"><div class="card-head"><h2>训练记录与诊断</h2><span class="small muted">按时间回看每一次进步</span></div>'+recordsTable(rows)+ (recent.some(r=>r.normalized<config.rules.target)?'<div class="training-plan">'+weaknessList({...s,weaknesses:s.weaknesses.filter(r=>r.domain===domain),recent},4)+'</div>':'')+'</section>'+(domain==='environment'?'<section class="card section-gap"><div class="card-head"><h2>学生作品区</h2>'+uploadEntry('上传作品','tiny secondary')+'</div>'+worksView()+'</section>':'')+(domain==='life'?'<div class="note section-gap">应急项目只展示训练成绩与补强计划。操作方案请遵循课程实训规程并由实训教师指导。</div>':'');
  }
  function recordsTable(rows){
    if(!rows.length)return '<div class="empty">'+ico('file')+'<p>暂无训练记录</p>'+button('导入 CSV / Excel','open-import')+'</div>';
    return '<div class="table-wrap"><table><thead><tr><th>训练时间</th><th>技能 / 任务</th><th>轮次</th><th>原始成绩</th><th>百分制</th><th>评价记录</th></tr></thead><tbody>'+[...rows].sort((a,b)=>b.date.localeCompare(a.date)||b.attempt-a.attempt).slice(0,100).map(r=>'<tr><td>'+esc(r.date.replace('T',' '))+'</td><td>'+esc(r.skill)+'<br><span class="muted">'+esc(r.task)+'</span></td><td>'+r.attempt+'</td><td>'+r.score+' / '+r.maxScore+'</td><td class="num"><b class="'+(r.normalized<config.rules.target?'score bad':'')+'" style="font-size:14px">'+score(r.normalized)+'</b><br><small class="muted">'+scoreBand(r.normalized)+'</small></td><td class="long">'+esc(r.feedback||'未提供')+(r.supportAction?'<br><small class="muted">训练支持：'+esc(r.supportAction)+'</small>':'')+(r.responseSeconds!==null&&r.responseSeconds!==undefined?'<br><small class="muted">回应 '+esc(r.responseSeconds)+' 秒</small>':'')+(r.ageGroup?'<br><small class="muted">年龄组 '+esc(r.ageGroup)+'</small>':'')+'</td></tr>').join('')+'</tbody></table></div>'+(rows.length>100?'<p class="small muted">展示最新 100 条，共 '+rows.length+' 条，可导出完整数据。</p>':'');
  }
  function lineChart(history){
    if(!history.length)return '<div class="empty">暂无同一任务的复练记录</div>';
    const w=640,h=260,left=40,right=20,top=25,bottom=43,x=i=>left+(w-left-right)*(history.length===1?.5:i/(history.length-1)),y=v=>h-bottom-(h-bottom-top)*v/100;
    let out='<svg class="chart-svg" viewBox="0 0 '+w+' '+h+'" role="img" aria-label="复练曲线：'+esc(history.map(r=>'第'+r.attempt+'轮'+r.normalized+'分').join('，'))+'">';
    [0,20,40,60,80,100].forEach(v=>{out+='<line x1="'+left+'" y1="'+y(v)+'" x2="'+(w-right)+'" y2="'+y(v)+'" stroke="#e5eff4"/><text x="'+(left-9)+'" y="'+(y(v)+4)+'" text-anchor="end">'+v+'</text>';});
    out+='<line x1="'+left+'" y1="'+y(config.rules.target)+'" x2="'+(w-right)+'" y2="'+y(config.rules.target)+'" stroke="#e8b763" stroke-dasharray="5 5"/>';
    if(history.length>1)out+='<polyline class="draw-line" pathLength="1" points="'+history.map((r,i)=>x(i)+','+y(r.normalized)).join(' ')+'" fill="none" stroke="#079bd2" stroke-width="3"/>';
    history.forEach((r,i)=>{const show=history.length<=8||i===0||i===history.length-1||i%6===0;out+='<circle cx="'+x(i)+'" cy="'+y(r.normalized)+'" r="5" fill="'+(r.normalized<config.rules.target?'#d96b65':'#079bd2')+'" stroke="white" stroke-width="2"/>'+(show?'<text x="'+x(i)+'" y="'+(y(r.normalized)-12)+'" text-anchor="middle" style="fill:#3d758f;font-weight:bold">'+score(r.normalized)+'</text><text x="'+x(i)+'" y="'+(h-bottom+19)+'" text-anchor="middle">第 '+r.attempt+' 轮</text>':'');});
    return out+'<text x="'+(w-right)+'" y="'+(y(config.rules.target)+15)+'" text-anchor="end" style="fill:#be944a;font-size:10px">目标 '+config.rules.target+' 分</text></svg>';
  }
  function portrait(){
    const s=data();let p=s.progress.find(r=>r.id===chartSelection)||s.progress.find(r=>r.skill==='安全应急')||s.progress[0];chartSelection=p?.id||'';
    const rank=YT.rank(s.coverage===3?s.average:null,config.rules),safety=s.recent.filter(r=>YT.isSafetySkill(r.skill)&&r.normalized<config.rules.target);
    const mascot=rank.level===3?'bear':rank.level===2?'fox':'bunny';
    return pageHead('三域能力画像','在成长花园，记录每一次努力与进步',button('动效'+(motion?'开启':'关闭'),'motion-toggle','motion-control','aria-pressed="'+motion+'"')+button(ico('download')+'导出成绩','export-csv','outline')+button('打印报告','print','outline'))+modeBanner()+'<div class="print-title"><p>'+studentDisplay()+'　'+(mode==='demo'?'历史档案 · 示例数据（生成）':'导入实训记录')+'</p></div><section class="portrait-greeting"><div class="portrait-toy" aria-hidden="true">'+ART.toy(mascot)+'</div><div><span class="eyebrow">MY GROWTH GARDEN</span><h2>成长，正在发生</h2><p>'+studentDisplay()+'<br>'+(mode==='demo'?checkpoint.replace('-','.')+' 阶段回看':'根据已录入的训练证据统计')+'</p></div><div class="portrait-score"><span class="rank-chip '+rank.className+'">'+rank.name+'</span><strong>'+score(s.average)+'</strong><small>已录入领域均值 / 100</small></div><div class="portrait-flower" aria-hidden="true">'+ART.flower('#f0c7bf')+'</div></section>'+(safety.length?'<div class="note bad section-gap">'+ico('warning')+'安全应急专项 '+score(safety[0].normalized)+' 分，低于目标 '+config.rules.target+' 分。请按原始评价安排专项复练。</div>':'')+'<div class="two portrait-charts section-gap"><section class="card"><div class="card-head"><h2>三域能力雷达</h2><span class="small muted">每一个方向，都在生长</span></div>'+radar(s)+'<div class="metric-list">'+s.abilities.map(a=>'<div><b style="color:'+a.color+'">'+score(a.value)+'</b><span>'+a.ability+' · '+a.count+' 项任务</span></div>').join('')+'</div></section><section class="card"><div class="card-head"><h2>复练成长曲线</h2><span class="small muted">同技能 · 同任务</span></div><select id="chart-select" aria-label="选择复练技能任务">'+(s.progress.length?s.progress.map(r=>'<option value="'+esc(r.id)+'" '+(r.id===chartSelection?'selected':'')+'>'+esc(r.skill)+' / '+esc(r.task)+'</option>').join(''):'<option>暂无复练记录</option>')+'</select>'+lineChart(p?.history||[])+'<div class="flex between"><span class="small muted">'+(p?.history.length>1?'初训 '+score(p.first)+' → 本阶段 '+score(p.normalized)+' 分':'继续录入同一任务的新一轮记录')+'</span>'+(p?.delta!==null&&p?.delta!==undefined?'<span class="pill '+(p.delta>=0?'good':'bad')+'">'+(p.delta>=0?'+':'')+score(p.delta)+' 分</span>':'')+'</div>'+(mode==='demo'?'<div class="portrait-actions">'+button('回看初训','growth-start','tiny secondary')+button('下一成长阶段','growth-next','tiny outline')+button('查看最新画像','growth-latest','tiny outline')+'</div>':'')+'</section></div>'+growthOverview(s)+'<div class="stats section-gap"><div class="stat"><b>'+s.rows.length+'</b><span>训练记录</span></div><div class="stat"><b>'+s.coverage+' / 3</b><span>领域覆盖</span></div><div class="stat"><b>'+s.progress.filter(r=>r.improved).length+'</b><span>达到目标的补强任务</span></div><div class="stat"><b>'+s.weaknesses.length+'</b><span>本阶段待补强任务</span></div></div><section class="card section-gap"><div class="card-head"><h2>证据诊断与专项补强</h2><span class="small muted">目标 '+config.rules.target+' 分</span></div>'+weaknessList(s,20)+'</section><details class="raw-records section-gap"><summary>画像计算口径与评分规则</summary><p class="small muted section-gap">成绩按得分与满分归一化。同领域、技能、任务取最新记录，领域等权平均；总览只计算已录入领域。缺项显示待补录。复练曲线比较同一技能、同一任务。</p>'+button('查看评分规则','rules','tiny secondary')+'</details>'+(p?'<details class="raw-records section-gap"><summary>查看 '+esc(p.skill)+' 的 '+p.history.length+' 轮原始记录</summary>'+recordsTable(p.history)+'</details>':'');
  }

  function dataCenter(){
    const s=data();return pageHead('数据与作品','文件导入、作品归档与数据备份',button(ico('upload')+'导入 CSV / Excel','open-import')+uploadEntry('上传环创作品'))+modeBanner()+'<div class="two"><section class="card"><div class="card-head"><h2>训练记录导入</h2>'+badge()+'</div><p class="small muted">支持 CSV、TSV 和 Excel .xlsx。预览字段映射与错误，确认后写入当前数据区。</p><div class="flex wrap">'+button('选择文件','open-import')+'<a class="btn outline" href="templates/blank-template.csv" download>空白 CSV 模板</a><a class="btn outline" href="templates/demo-sample.csv" download>PPT 案例 CSV</a><a class="btn outline" href="templates/demo-sample.xlsx" download>PPT 案例 Excel</a><a class="btn outline" href="templates/semester-sample.csv" download>学期成长档案 CSV</a></div><div class="note section-gap">示例文件均标注 demo，不能导入真实数据区。真实导入表示用户提供的记录，导入时请核对原始来源。</div></section><section class="card"><div class="card-head"><h2>本机数据备份</h2><span class="pill">本地保存</span></div><p class="small muted">完整备份包含记录、任务、笔记和作品文件；不包含账号密码。数据按账号及数据模式隔离。</p><div class="flex wrap">'+button('完整备份','backup','outline')+button('恢复备份','restore','outline')+button('导出全部成绩','export-all','outline')+'</div><div class="note section-gap">移动项目目录或清除浏览器数据前，请先备份。档案按数据性质分别保存。</div></section></div><section class="card section-gap"><div class="card-head"><h2>导入批次</h2><span class="small muted">'+db().batches.length+' 个批次</span></div>'+(db().batches.length?'<div class="table-wrap"><table><thead><tr><th>文件</th><th>模式</th><th>成功</th><th>重复跳过</th><th>导入时间</th><th>操作</th></tr></thead><tbody>'+[...db().batches].reverse().map(b=>'<tr><td>'+esc(b.filename)+'</td><td>'+esc(b.mode==='demo'?'演示':'真实')+'</td><td>'+b.ids.length+'</td><td>'+b.duplicates+'</td><td>'+esc(b.time)+'</td><td>'+button('撤销批次','undo-batch','tiny danger','data-id="'+esc(b.id)+'"')+'</td></tr>').join('')+'</tbody></table></div>':'<div class="empty">暂无文件导入批次</div>')+'</section><section class="card section-gap"><div class="card-head"><h2>学生作品区</h2>'+uploadEntry('上传作品','tiny secondary')+'</div>'+worksView()+'</section><section class="card section-gap"><div class="card-head"><h2>当前学生全部记录</h2><span class="small muted">'+studentDisplay()+'</span></div>'+recordsTable(s.rows)+'</section>';
  }
  function workStatus(w){return w.evaluation?'已评价':w.recordIds?.length?'历史评价':'待教师评价';}
  function evaluationView(w){
    const e=w.evaluation;
    if(!e)return '<p class="work-status small">'+(w.recordIds?.length?'已保存历史评分记录':'作品已提交，等待教师在独立评价区批阅')+'</p>';
    return '<div class="work-evaluation"><b>教师反馈 · '+esc(e.teacherName)+'</b><p>'+esc(e.feedback)+'</p><div class="evaluation-scores">'+YT.domains[1].skills.map((skill,i)=>'<span>'+skill+' <b>'+score(e.scores[i])+'</b></span>').join('')+'</div><small>评价时间：'+esc(e.date)+'</small></div>';
  }
  function worksView(){
    const works=db().works.filter(w=>!student||w.studentId===student);
    const submitted=works.length?'<div class="work-grid">'+works.map(w=>'<article class="work-card"><div class="work-preview" data-work-preview="'+esc(w.id)+'">'+ico('file')+'</div><div class="work-info"><div class="flex between"><h3 style="margin:0">'+esc(w.title)+'</h3><span class="pill '+(w.evaluation?'good':'warn')+'">'+workStatus(w)+'</span></div><p>'+esc(w.name)+' · '+esc(w.studentId)+' · '+esc(w.ageGroup)+'<br>'+esc(w.filename)+' · '+esc(w.date)+'</p><p>'+esc(w.description)+'</p>'+evaluationView(w)+'<div class="flex section-gap">'+button('查看 / 下载','download-work','tiny outline','data-id="'+esc(w.id)+'"')+(!isTeacher()?button('删除作品','delete-work','tiny danger','data-id="'+esc(w.id)+'"'):'')+'</div></div></article>').join('')+'</div>':'<div class="submission-empty">'+ico('upload')+'<div><b>把你的设计放进成长档案</b><p>上传图片或 PDF，填写设计说明。提交后可在这里查看教师反馈。</p><small>PNG / JPG / WebP / PDF · 单件最多 5 MB</small></div></div>';
    return submitted+'<div class="gallery-heading"><div><span class="eyebrow">ENVIRONMENT DESIGN COLLECTION</span><h3>环创作品展</h3><p>十个课程示例，探索适合不同年龄的儿童空间。</p></div><span class="pill">课程示例 · 10 件</span></div><div class="sample-grid">'+YT_GALLERY.map(w=>'<article class="sample-work"><button class="sample-picture" data-action="view-sample" data-id="'+w.id+'" aria-label="查看'+esc(w.title)+'"><img src="'+w.src+'" alt="'+esc(w.title)+'课程示例设计图" loading="lazy"><span class="sample-label">课程示例</span></button><div class="sample-info"><small>'+esc(w.age)+' · '+esc(w.category)+'</small><h3>'+esc(w.title)+'</h3><p>'+esc(w.description)+'</p>'+button('欣赏设计','view-sample','tiny outline','data-id="'+w.id+'"')+'</div></article>').join('')+'</div>';
  }
  function reviewQueue(){
    if(mode==='demo')return demo.works.map(work=>({work,key:'demo'}));
    const keys=new Set(accounts.filter(a=>a.role!=='teacher').map(a=>'real.'+a.id));keys.add('real.demo');keys.add(realKey());
    try{for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k?.startsWith(storePrefix+'real.'))keys.add(k.slice(storePrefix.length));}}catch{}
    return [...keys].flatMap(key=>read(key,{works:[]}).works.map(work=>({work,key})));
  }
  function teacherPage(){
    const queue=reviewQueue().sort((a,b)=>Boolean(a.work.evaluation)-Boolean(b.work.evaluation)||b.work.date.localeCompare(a.work.date)),pending=queue.filter(x=>!x.work.evaluation&&!x.work.recordIds?.length).length;
    return pageHead('教师评价与打分','学生提交作品后，由教师独立批阅。评价结果回到对应学生的档案。')+'<div class="review-overview"><span class="review-icon">'+ico('check')+'</span><div><h3>作品评阅台</h3><p>当前'+(mode==='demo'?'示例数据':'实训记录')+'区 · '+queue.length+' 件提交 · '+pending+' 件待评价</p></div><span class="pill role-badge">教师账号 · '+esc(auth.name)+'</span></div><section class="card section-gap"><div class="card-head"><h2>学生提交作品</h2><span class="small muted">设计说明、评语与评分分别保存</span></div>'+(queue.length?'<div class="review-grid">'+queue.map(({work:w,key})=>'<article class="review-card"><div class="work-preview" data-work-preview="'+esc(w.id)+'">'+ico('file')+'</div><div class="work-info"><div class="flex between"><h3>'+esc(w.title)+'</h3><span class="pill '+(w.evaluation?'good':'warn')+'">'+workStatus(w)+'</span></div><p>'+esc(w.name)+' · '+esc(w.studentId)+' · '+esc(w.ageGroup)+'<br>第 '+esc(w.attempt)+' 版 · '+esc(w.date)+'</p><b class="small">学生设计说明</b><p>'+esc(w.description)+'</p>'+evaluationView(w)+'<div class="flex wrap section-gap">'+button('查看作品','review-file','tiny outline','data-id="'+esc(w.id)+'" data-key="'+esc(key)+'"')+button(w.evaluation?'修改评价':'评价与打分','review-work','tiny','data-id="'+esc(w.id)+'" data-key="'+esc(key)+'"')+'</div></div></article>').join('')+'</div>':'<div class="empty">'+ico('file')+'<p>等待学生提交作品</p><small>在同一浏览器内，学生先提交并退出；教师登录后即可批阅。历史档案与成绩录入分别评阅。</small></div>')+'</section>';
  }
  function reviewTarget(id,key){
    if(!isTeacher())throw Error('请使用教师账号进入独立评价区');
    const target=reviewQueue().find(x=>x.key===key&&x.work.id===id);if(!target)throw Error('作品不存在或不属于当前数据区');return target;
  }
  function reviewModal(id,key){
    const {work:w}=reviewTarget(id,key),e=w.evaluation;
    modal('教师评价 · '+w.title,'<div class="note">'+esc(w.name)+' · '+esc(w.studentId)+' · '+esc(w.ageGroup)+'<br>学生设计说明：'+esc(w.description)+'</div><form id="review-form" data-id="'+esc(id)+'" data-key="'+esc(key)+'"><div class="field section-gap"><label>教师评语</label><textarea name="feedback" required maxlength="4000" placeholder="依据作品填写亮点、需改进之处和复练建议">'+esc(e?.feedback||'')+'</textarea></div><h3>四项能力评分（百分制）</h3><div class="rowform">'+YT.domains[1].skills.map((skill,i)=>'<div class="field"><label>'+skill+'</label><input name="rubric'+i+'" type="number" min="0" max="100" step="0.1" required value="'+esc(e?.scores[i]??'')+'"></div>').join('')+'</div><label class="checkbox"><input type="checkbox" name="confirmed" required>我已查看作品，确认评语与评分依据。</label><div id="review-error" class="error" role="alert"></div><button class="btn section-gap" type="submit">保存教师评价</button></form>');
  }
  function saveReview(form){
    const {work:w,key}=reviewTarget(form.dataset.id,form.dataset.key),v=Object.fromEntries(new FormData(form)),scores=YT.domains[1].skills.map((_,i)=>{const value=v['rubric'+i];if(value===undefined||value.trim()==='')throw Error('请完成四项能力评分');const n=Number(value);if(!Number.isFinite(n)||n<0||n>100)throw Error('评分须在 0–100 之间');return n;});
    if(!v.feedback?.trim()||v.feedback.length>4000||!v.confirmed)throw Error('请填写教师评语并确认评价依据');
    const next=key==='demo'?YT.clone(demo):read(key,{records:[],works:[],tasks:[],notes:{},batches:[]}),work=next.works.find(x=>x.id===w.id),date=new Date().toLocaleString('sv-SE',{timeZone:'Asia/Shanghai'}).replace(' ','T');
    next.records=next.records.filter(r=>!work.recordIds.includes(r.id));
    if(work.evaluation)work.evaluationHistory=[...(work.evaluationHistory||[]),work.evaluation];
    work.evaluation={teacherId:auth.id,teacherName:auth.name,feedback:v.feedback.trim(),scores,date};work.recordIds=[];
    YT.domains[1].skills.forEach((skill,i)=>{const id=crypto.randomUUID();work.recordIds.push(id);next.records.push({id,studentId:work.studentId,name:work.name,domain:'environment',skill,task:work.title,score:scores[i],maxScore:100,normalized:scores[i],date,attempt:work.attempt,feedback:work.evaluation.feedback,source:'教师作品评价',recordId:work.id+'-'+i,kind:mode,filename:work.filename,importedAt:new Date().toISOString(),ageGroup:work.ageGroup,responseSeconds:null,workId:work.id,teacherId:auth.id});});
    write(key,next);if(key==='demo')demo=next;if(key===realKey())real=next;closeModal();render();toast('教师评价已保存，学生画像已更新');
  }
  function tasksView(){
    const tasks=db().tasks.filter(t=>!student||t.studentId===student);
    if(!tasks.length)return '<p class="small muted">暂无复练任务。点击诊断中的“专项复练”，可把建议加入清单。</p>';
    return tasks.map(t=>{const origin=db().records.find(r=>r.id===t.recordId);const next=data().rows.filter(r=>r.studentId===t.studentId&&r.domain===t.domain&&r.skill===t.skill&&r.task===t.task&&r.id!==t.recordId&&(!origin||r.date>origin.date||r.date===origin.date&&r.attempt>origin.attempt));const recent=YT.latest(next)[0],met=recent&&recent.normalized>=config.rules.target;return '<div class="activity"><span class="step-num">'+ico(met?'check':'target')+'</span><div style="flex:1"><b class="small">'+esc(t.title)+'</b><br><small class="muted">'+esc(t.studentId)+' · '+esc(t.date)+' · '+(met?'最新复练 '+score(recent.normalized)+' 分，达到目标':recent?'最新复练 '+score(recent.normalized)+' 分，继续补强':'等待同任务新一轮记录')+'</small></div><span class="pill '+(met?'good':'warn')+'">'+(met?'达到目标':'待复练')+'</span>'+button('移除','remove-task','tiny outline','data-id="'+esc(t.id)+'"')+'</div>';}).join('');
  }
  let fileDB;
  async function openFileDB(){if(fileDB)return fileDB;fileDB=await new Promise((resolve,reject)=>{const req=indexedDB.open('yitong-growth-files-v1',1);req.onupgradeneeded=()=>req.result.createObjectStore('files');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(Error('浏览器作品存储不可用'));});return fileDB;}
  async function fileOp(method,key,value){const d=await openFileDB();return new Promise((resolve,reject)=>{const tx=d.transaction('files',method==='get'?'readonly':'readwrite'),s=tx.objectStore('files');let result;const r=method==='get'?s.get(key):method==='put'?s.put(value,key):s.delete(key);r.onsuccess=()=>{result=r.result;};tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(Error('作品保存失败，请检查浏览器存储空间'));tx.onabort=()=>reject(Error('作品保存失败'));});}
  async function loadWorkImages(){const snapshotMode=mode;for(const el of $$('[data-work-preview]')){try{const f=await fileOp('get',el.dataset.workPreview);if(f&&snapshotMode===mode&&el.isConnected&&f.type.startsWith('image/')){const url=URL.createObjectURL(f);viewURL.push(url);const img=new Image();img.alt='环创作品预览';img.src=url;el.replaceChildren(img);}}catch{el.textContent='预览暂不可用';}}}
  function learning(id){
    const m=menus.find(m=>m[0]===id),resource=config.resources.filter(r=>r.menu===id);
    return pageHead(m?.[1]||'学习资料','离线课程任务与学习笔记')+modeBanner()+(id==='growth'?'<section class="card section-gap"><h2>我的复练任务</h2>'+tasksView()+'</section>':'')+'<div class="lesson-list section-gap">'+(lessons[id]||[]).map((l,i)=>{const key=id+'-'+i,notes=db().notes[key],open=lessonOpen===key;return '<article class="lesson"><div class="flex between"><div><h3>'+l[0]+'</h3><p style="margin:0">'+l[1]+'</p></div>'+button(notes?.done?'已完成 · 查看':'进入学习','lesson','outline','data-id="'+key+'"')+'</div>'+(open?'<div class="lesson-detail"><h3>学习任务</h3><ol>'+l[2].map(t=>'<li>'+t+'</li>').join('')+'</ol><form data-form="lesson" data-key="'+key+'"><label>学习记录与反思</label><textarea name="note" required maxlength="4000" placeholder="记录你的观察、依据与下一步行动">'+esc(notes?.text||'')+'</textarea><label class="checkbox section-gap"><input type="checkbox" name="done" '+(notes?.done?'checked':'')+'>我已完成任务，记录学习反思</label><button type="submit" class="btn section-gap">保存学习记录</button></form></div>':'')+'</article>';}).join('')+'</div><section class="card section-gap"><div class="card-head"><h2>教师资料夹</h2>'+button('配置资料','nav','tiny secondary','data-page="settings"')+'</div>'+(resource.length?resource.map(r=>'<div class="activity">'+ico('file')+'<div><a href="'+esc(YT.safeURL(r.url))+'" target="_blank" rel="noopener noreferrer">'+esc(r.title)+'</a><br><small>'+esc(r.date||'未填写日期')+' · 打开链接需要网络</small></div></div>').join(''):'<p class="small muted" style="margin:0">暂无外部资料。可在平台配置中添加教师确认的资料链接、出处日期。</p>')+'</section>';
  }
  function assistantAnswer(kind,question){
    const s=data(),label=mode==='demo'?'历史档案 · 示例数据':'导入实训记录',person=students().find(x=>x.id===student),r=s.weaknesses[0];
    const head='依据：'+label+'，'+(person?person.name+'（'+person.id+'）':'暂无学生记录')+'。\n';
    if(/实时|接口|连接设备|同步/.test(question))return head+'本版本通过导出的文件汇总记录。VR 使用独立配套软件，环创作品手动上传，智能娃娃成绩文件导入。尚未连接厂商接口，也没有实时设备数据。';
    if(kind==='learn'){
      if(!r)return head+(s.recent.length?'已采集技能已达到目标。建议继续补充缺失领域，再复核训练证据。':'请先导入训练记录，再生成个人复练建议。');
      const t=YT.training(r);return head+'建议先复练「'+r.skill+'」，当前 '+score(r.normalized)+' 分，目标 '+config.rules.target+' 分。\n原始反馈：'+(r.feedback||'文件未提供文字反馈')+'\n\n'+t.title+'\n'+t.steps.map((t,i)=>(i+1)+'. '+t).join('\n')+'\n\n回流证据：'+t.evidence;
    }
    if(kind==='evaluate')return head+(s.recent.length?'三域能力：\n'+s.abilities.map(a=>a.ability+'：'+score(a.value)+(a.value===null?'':' 分（'+a.count+' 项任务）')).join('\n')+'\n\n低于目标 '+config.rules.target+' 分的任务：'+(s.weaknesses.length?s.weaknesses.map(r=>r.skill+' '+score(r.normalized)+' 分').join('、'):'已采集任务均达到目标')+'。\n评分依据：得分/满分转百分制，各技能任务取最新记录，再计算领域均值。':'暂无可评价记录，请先导入文件。');
    if(kind==='research')return head+'研究观察建议：比较同一学生、同一技能、同一任务的首轮与最新一轮。\n'+s.progress.filter(p=>p.history.length>1).map(p=>p.skill+'：'+score(p.first)+' → '+score(p.normalized)+' 分，变化 '+(p.delta>=0?'+':'')+score(p.delta)+' 分。').join('\n')+'\n\n可以记录的问题：复练后哪类失分减少？教师反馈与成绩是否一致？\n当前记录仅能描述训练变化，不能据此推断因果效果或总体教学成效。';
    if(kind==='teach')return head+'课堂任务草案：'+(r?YT.training(r).title:'三域证据汇总练习')+'\n准备：确认训练情境、评价量规、设备与学生学号。\n课堂：教师示范，学生在对应配套软件或设备完成实训。\n评价：导出训练记录，核对来源与评分，再导入生成画像。\n课后：为低于目标的技能安排同任务复练。\n'+(r?'优先观察：'+r.skill+'，原始反馈“'+(r.feedback||'未提供')+'”。':'请根据课程目标补充观察项。');
    if(kind==='manage'){
      const list=students(),weak=list.flatMap(st=>YT.summary(db().records,st.id,config.rules).weaknesses.map(r=>st.name+' / '+r.skill+' / '+score(r.normalized)+' 分'));
      return '依据：'+label+'，当前数据区共有 '+list.length+' 名学生、'+db().records.length+' 条成绩、'+db().works.length+' 件作品。\n\n待补强清单：\n'+(weak.slice(0,15).join('\n')||'暂无待补强记录')+'\n\n管理建议：先补齐三域缺失记录，再按任务分组安排复练。可导出完整备份留存。';
    }
    return head+'环创共创提纲（根据文字任务生成）：\n主题：'+(question.trim()||'可操作的分龄互动环境')+'\n设计前填写：目标年龄、活动目标、材料与操作方式。\n草图标注：互动位置、教师观察点、作品版本。\n作品证据：上传草图或成品图片，附设计说明与教师评价。\n迭代验证：比较同一任务的教师评分，记录修改依据。\n\n当前助手不进行图像识别，分龄适宜性与材料安全性由教师结合实物确认。';
  }
  function assistant(){
    const a=assists.find(a=>a[0]===selectedAssist);if(!chat.length)chat=[{role:'assistant',text:assistantAnswer(selectedAssist,'')}];
    const quick={learn:['给我复练计划','我该补强哪项技能'],research:['比较复练前后变化','帮我设计观察问题'],teach:['生成课堂任务草案','安排三域实训活动'],evaluate:['诊断我的三域能力','解释画像评分依据'],manage:['查看班级待补强清单','汇总数据覆盖情况'],create:['分龄互动环创方案','家园沟通情境设计']}[selectedAssist];
    return pageHead(a[1]+'工作台','离线规则助手，依据当前数据和课程任务生成结构化建议')+modeBanner()+'<section class="card"><div class="card-head"><h2>'+a[1]+' · '+a[2]+'</h2><span class="pill">本地运行</span></div><div class="note">问题由本地规则路由处理，支持学习计划、评价诊断、课堂任务和研究观察。开放问答与自动图像评价尚未接入模型。</div><div class="assistant-quick">'+quick.map(q=>'<button data-action="ask-quick" data-question="'+esc(q)+'">'+q+'</button>').join('')+'</div><div class="assistant-chat">'+chat.map(c=>'<div class="chat-message '+c.role+'">'+(c.role==='assistant'?'<span class="eyebrow">'+a[1]+' · '+(mode==='demo'?'示例数据':'实训记录')+'</span>':'')+esc(c.text)+'</div>').join('')+'</div><form id="chat-form" class="chat-form"><input name="question" aria-label="向六助提问" placeholder="输入训练问题，或点击上方建议问题" required maxlength="500"><button class="btn" type="submit">提问 '+ico('arrow')+'</button></form><div class="flex wrap section-gap">'+button('查看能力画像','nav','outline','data-page="portrait"')+button('添加建议复练任务','assistant-task','outline')+'</div></section>';
  }
  const tourSteps=[
    {time:'0:00 – 0:30',title:'成长空间与六助全景',page:'home',month:'2026-07',script:'正常登录，展示六菜单、六助与学期成长档案。档案为示例数据，说明三域记录如何汇总与回看。'},
    {time:'0:30 – 1:30',title:'家园共育：初训与专项补强',page:'smart',domain:'family',month:'2026-03',script:'回看第一月家长沟通实训。根据专业依据短板打开专项复练计划，展示任务、原始评价及回流要求。'},
    {time:'1:30 – 2:30',title:'环境创设：作品与阶段复评',page:'smart',domain:'environment',month:'2026-04',script:'查看专项训练期的环境创设记录，展示年龄组、作品上传、教师评分和版本复评流程。'},
    {time:'2:30 – 3:50',title:'一日生活：从新锐走向尖兵',page:'portrait',month:'2026-05',script:'查看三域达到尖兵阶段的画像与同任务复练曲线。点击下一成长阶段，回看综合训练进入精英阶段的记录。'},
    {time:'3:50 – 4:25',title:'学期画像汇总与精英成长',page:'portrait',month:'2026-07',script:'展示完整 5 个月三域成长曲线、初训与最新画像对比，以及新锐、尖兵、精英关键节点。说明这是示例数据的训练轨迹。'},
    {time:'4:25 – 5:00',title:'成绩录入与证据归档',page:'data',month:'2026-07',script:'展示训练记录、文件映射、作品归档和完整备份。后续实际成绩通过独立的成绩录入区导入，替换展示案例时保留真实来源。'}
  ];
  function elapsed(){return tour?Math.floor((tour.running?Date.now()-tour.started:tour.elapsed)/1000):0;}
  function timeString(v){return String(Math.floor(v/60)).padStart(2,'0')+':'+String(v%60).padStart(2,'0');}
  function tourbar(){const st=tourSteps[tour.step];return '<div class="tourbar"><div><b>成长汇报　'+(tour.step+1)+' / 6　'+st.title+'</b><br><small>'+st.time+'　'+(mode==='demo'?'历史档案 · 示例数据':'实训记录')+'</small></div><div class="flex"><span id="tour-time" class="time">'+timeString(elapsed())+'</span>'+button(tour.running?'暂停':'继续','tour-pause','white')+button('讲解提示','tour-hint','white')+button('上一步','tour-prev','white',''+(tour.step===0?'disabled':''))+button('下一步','tour-next','gold',''+(tour.step===5?'disabled':''))+button('结束','tour-end','white')+'</div></div>';}
  function competition(){
    return pageHead('5 分钟成长汇报','沿训练记录回看成长，可暂停计时和自由切换阶段',button(ico('play')+'开始成长汇报','tour-start','gold'))+'<section class="hero"><div><span class="eyebrow">5 MINUTES · A COMPLETE LEARNING LOOP</span><h1>一学期进阶，成长可见</h1><p>林悦的历史档案 · 示例数据覆盖 5 个月。沿着任务、诊断与复练回看三个成长阶段。</p></div><div class="timer">05:00</div></section><div class="timeline-list section-gap">'+tourSteps.map((s,i)=>'<article class="timeline-step '+(tour?.step===i?'active':'')+'"><span class="time">'+s.time+'</span><div><h3>'+s.title+'</h3><p>'+s.script+'</p>'+button('预览此步骤','tour-goto','tiny outline','data-step="'+i+'"')+'</div></article>').join('')+'</div><div class="note warn section-gap">成长汇报按历史时点回看记录，不改写已有成绩。计时可暂停，页面由你控制。历史档案与成绩录入独立保存。</div>';
  }
  function settings(){
    return pageHead('平台与资料配置','设置真实入口，保留软件独立运行与文件回流方式')+'<div class="two"><section class="card"><div class="card-head"><h2>三域平台入口</h2><span class="pill">本机配置</span></div><form id="settings-form">'+YT.domains.map(d=>'<div class="settings-platform"><h3>'+d.name+'</h3><div class="field"><label>平台名称</label><input name="'+d.id+'-name" value="'+esc(config.platforms[d.id].name)+'" required maxlength="100"></div><div class="field"><label>官网或软件说明页链接</label><input name="'+d.id+'-url" type="url" value="'+esc(config.platforms[d.id].url)+'" placeholder="https://…（尚无地址可留空）"></div><div class="field"><label>使用说明</label><textarea name="'+d.id+'-note" maxlength="500">'+esc(config.platforms[d.id].note)+'</textarea></div></div>').join('')+'<button type="submit" class="btn section-gap">保存平台配置</button></form><div class="note section-gap">仅支持 http / https 链接。VR 独立软件请从 Windows 现有快捷方式启动；这里可配置下载或说明页，配套软件通过 Windows 快捷方式运行。</div></section><div class="stack"><section class="card"><div class="card-head"><h2>课程评分规则</h2></div><form id="rules-form"><div class="rowform">'+[['pass','合格参考线'],['target','复练目标线'],['excellent','优秀参考线']].map(([k,l])=>'<div class="field"><label>'+l+' / 100</label><input name="'+k+'" type="number" min="0" max="100" step="1" required value="'+config.rules[k]+'"></div>').join('')+'</div><button type="submit" class="btn">保存评分规则</button></form><p class="small muted section-gap">默认 60 / 80 / 90 是当前课程参考规则，可由教师调整，属于教学评价口径。</p></section><section class="card"><div class="card-head"><h2>教师资料夹</h2></div><form id="resource-form"><div class="field"><label>所属菜单</label><select name="menu">'+menus.filter(m=>m[0]!=='smart').map(m=>'<option value="'+m[0]+'">'+m[1]+'</option>').join('')+'</select></div><div class="field"><label>资料名称</label><input name="title" required maxlength="100"></div><div class="rowform"><div class="field"><label>资料日期</label><input name="date" type="date"></div><div class="field"><label>原文链接</label><input name="url" type="url" required placeholder="https://…"></div></div><button type="submit" class="btn">添加资料</button></form>'+config.resources.map((r,i)=>'<div class="activity"><div style="flex:1"><b class="small">'+esc(r.title)+'</b><br><small class="muted">'+esc(r.date)+'</small></div>'+button('删除','delete-resource','tiny danger','data-index="'+i+'"')+'</div>').join('')+'</section><section class="card"><h2>配置导出</h2><p class="small muted">把平台链接、课程规则和资料配置带到另一台电脑。</p><div class="flex wrap">'+button('导出配置','export-config','outline')+button('导入配置','import-config','outline')+'</div></section></div></div>'+XiaoGuan.settings(config);
  }
  function archiveInfo(){
    const s=data(),rows=db().records.filter(r=>r.studentId===selectedStudent()),sources=[...new Set(rows.map(r=>r.kind==='demo'?'历史档案 · 示例数据（生成）':r.source||'用户录入'))];
    modal('档案说明',mode==='demo'?'<p>这里是林悦的学期<strong>示例数据</strong>档案，覆盖 2026 年 3 月至 2026 年 7 月。成绩由系统生成，用于展示任务、诊断、复练和成长画像的操作流程。</p><div class="note">这些成绩不代表已经发生的实际训练，也不能作为教学干预效果的实证结果。实际成绩请在“成绩录入”中独立导入。</div>':'<p>此处统计用户导入的训练文件及教师登记的作品评价。请按平台原始导出或实际教师评价录入。</p>','',false);
    $('.modal-body').insertAdjacentHTML('beforeend','<div class="archive-info-grid"><div>当前学生<b>'+studentDisplay()+'</b></div><div>记录总数<b>'+rows.length+' 条</b></div><div>记录性质<b>'+(mode==='demo'?'示例数据':'用户提交的实训记录')+'</b></div><div>画像时点<b>'+(mode==='demo'?checkpoint:'最新导入记录')+'</b></div></div><p class="small muted section-gap">来源：'+sources.map(esc).join('、')+'。来源平台、文件名、记录编号和数据性质随完整备份及成绩导出保留。</p>');
  }
  function rulesModal(){modal('评分规则与画像依据','<p>原始成绩保留得分和满分，展示分数按百分制归一化。同领域、技能、任务按训练时间取最新记录。</p><p>每个领域等权平均其最新技能任务，三域总览等权平均已采集领域。复练比较同一任务的历史成绩，时间相同按轮次排序。</p><p>补强标记需要首轮低于 '+config.rules.target+' 分、最新一轮达到 '+config.rules.target+' 分，且至少有两条记录。缺失数据不会当作零分。</p><div class="note">规则：合格参考 '+config.rules.pass+'，复练目标 '+config.rules.target+'，优秀参考 '+config.rules.excellent+'。评价规则可由教师调整。</div>');}
  function planModal(id){const r=db().records.find(r=>r.id===id);if(!r)return;const t=YT.training(r);modal(t.title,'<div class="flex between">'+badge()+'<span class="score bad">'+score(r.normalized)+' 分</span></div><p class="small muted section-gap">'+esc(r.name)+' · '+esc(r.task)+'<br>原始反馈：'+esc(r.feedback||'未提供')+'</p><ol style="line-height:2;font-size:13px">'+t.steps.map(s=>'<li>'+s+'</li>').join('')+'</ol><div class="note">回流证据：'+esc(t.evidence)+'。复练完成后，请导入新一轮记录，曲线随数据更新。</div>',button('添加复练任务','add-task','','data-id="'+esc(id)+'"'));}
  function addTask(id){const r=db().records.find(r=>r.id===id);if(!r){toast('先导入可诊断的训练记录');return;}const t=YT.training(r);if(db().tasks.some(t=>t.recordId===id&&t.status==='pending')){toast('该复练任务已添加');return;}mutate(d=>d.tasks.push({id:crypto.randomUUID(),recordId:id,studentId:r.studentId,title:t.title,domain:r.domain,skill:r.skill,task:r.task,status:'pending',date:new Date().toISOString().slice(0,10)}));closeModal();toast('已加入复练清单');if(page==='assistant')render();}
  function importModal(){
    importState=null;
    modal('导入训练记录','<div class="note">目标数据区：'+(mode==='demo'?'示例数据':'实训记录')+'。文件选择后先预览和校验，再确认写入。</div><div class="upload-zone section-gap">'+ico('upload')+'<p>选择平台导出的 CSV、TSV 或 Excel .xlsx 文件<br>单文件 ≤ 5 MB，最多 5000 条记录</p><input id="import-file" type="file" accept=".csv,.tsv,.xlsx" aria-label="选择训练记录文件"></div><div class="flex wrap"><a href="templates/blank-template.csv" download>下载空白模板</a><a href="templates/demo-sample.csv" download>下载 PPT 案例 CSV</a><a href="templates/demo-sample.xlsx" download>下载 PPT 案例 Excel</a><a href="templates/semester-sample.csv" download>下载学期成长档案</a></div><div id="import-content" class="section-gap"></div><div id="import-error" class="error" role="alert"></div>','',true);
  }
  async function readImport(file){
    if(!file)return;$('#import-error').textContent='正在读取…';
    try{const result=await YTImporter.read(file);importState={file: file.name,...result,map:YT.autoMap(result.table.headers),mode};drawImport();$('#import-error').textContent='';}catch(e){importState=null;$('#import-content').innerHTML='';$('#import-error').textContent=e.message;}
  }
  function drawImport(){
    const s=importState;
    $('#import-content').innerHTML='<div class="flex between wrap"><b>'+esc(s.file)+'</b><span class="small muted">'+s.table.rows.length+' 条 · '+esc(s.encoding||'Excel')+'</span></div>'+(s.workbook?'<div class="field section-gap"><label>工作表</label><select id="import-sheet">'+s.workbook.sheets.map((sh,i)=>'<option value="'+i+'" '+(i===(s.sheet||0)?'selected':'')+'>'+esc(sh.name)+'</option>').join('')+'</select></div>':'')+'<h3 class="section-gap">字段映射</h3><div class="mapping">'+YT.fields.map(([k,l,required])=>'<div><label>'+l+(required?' *':'')+'</label><select data-map="'+k+'"><option value="-1">不导入 / 使用默认值</option>'+s.table.headers.map((h,i)=>'<option value="'+i+'" '+(s.map[k]===i?'selected':'')+'>'+esc(h)+'</option>').join('')+'</select></div>').join('')+'</div><div class="field section-gap"><label>默认来源平台（文件有来源列时优先使用文件值）</label><input id="batch-source" value="用户文件导入" maxlength="100"></div><div id="validation-result"></div><div class="note section-gap">全部错误修正后才允许确认，整批写入。完全重复的记录跳过，冲突的成绩不会覆盖原记录。</div><label class="checkbox section-gap"><input id="import-confirm" type="checkbox">我已核对来源和数据性质。'+(s.mode==='real'?'确认这是实际训练导出的记录，不是演示数据。':'确认导入演示区，不作为真实训练成绩。')+'</label><div class="flex section-gap">'+button('确认导入','confirm-import','','disabled id="confirm-import-button"')+'</div>';
    validateImport();
  }
  function validateImport(){
    if(!importState)return;const s=importState,validation=YT.validate(s.table,s.map,s.mode,db().records,s.file,$('#batch-source')?.value);s.validation=validation;
    $('#validation-result').innerHTML='<div class="flex wrap section-gap"><span class="pill good">可导入 '+validation.valid.length+' 条</span><span class="pill">重复跳过 '+validation.duplicates+' 条</span><span class="pill '+(validation.errors.length?'bad':'good')+'">错误 '+validation.errors.length+' 条</span></div>'+[...validation.warnings,...(s.table.warnings||[])].map(w=>'<div class="note warn section-gap">'+esc(w)+'</div>').join('')+(validation.errors.length?'<div class="error-list section-gap">'+validation.errors.slice(0,50).map(e=>'<p>第 '+e.row+' 行：'+esc(e.message)+'</p>').join('')+'</div>':'')+(validation.valid.length?'<div class="table-wrap section-gap"><table><thead><tr><th>学号</th><th>模块</th><th>技能</th><th>原始成绩</th><th>百分制</th><th>轮次</th><th>时间</th></tr></thead><tbody>'+validation.valid.slice(0,10).map(r=>'<tr><td>'+esc(r.studentId)+'</td><td>'+YT.domains.find(d=>d.id===r.domain).name+'</td><td>'+esc(r.skill)+'</td><td>'+r.score+'/'+r.maxScore+'</td><td>'+r.normalized+'</td><td>'+r.attempt+'</td><td>'+r.date.replace('T',' ')+'</td></tr>').join('')+'</tbody></table></div><p class="small muted">预览前 10 条，确认将导入全部有效记录。</p>':'');
    updateImportButton();
  }
  function updateImportButton(){const s=importState;if($('#confirm-import-button'))$('#confirm-import-button').disabled=!s||s.validation.errors.length>0||!s.validation.valid.length||!$('#import-confirm')?.checked;}
  function confirmImport(){
    if(!importState||importState.mode!==mode)throw Error('数据模式已变化，请重新选择文件');validateImport();const s=importState;if(s.validation.errors.length||!s.validation.valid.length||!$('#import-confirm').checked)throw Error('请先修正错误并核对数据来源');
    const batchId=crypto.randomUUID();s.validation.valid.forEach(r=>r.batchId=batchId);
    mutate(d=>{d.records.push(...s.validation.valid);d.batches.push({id:batchId,filename:s.file,mode,ids:s.validation.valid.map(r=>r.id),duplicates:s.validation.duplicates,time:new Date().toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'})});});
    student=s.validation.valid[0].studentId;const n=s.validation.valid.length;closeModal();render();toast('成功导入 '+n+' 条记录，画像已更新');
  }
  function uploadModal(){
    if(isTeacher())throw Error('请用学生账号提交作品，教师账号用于独立评阅');
    modal('提交我的环创作品','<div class="note">作品保存在'+(mode==='demo'?'示例数据':'实训记录')+'区。这里填写作品与设计说明；教师在独立评价区批阅。</div><form id="work-form" class="section-gap"><div class="rowform"><div class="field"><label>学生学号</label><input name="studentId" readonly value="'+esc(auth.studentId)+'"></div><div class="field"><label>学生姓名</label><input name="name" readonly value="'+esc(auth.name)+'"></div></div><div class="field"><label>作品标题 / 训练任务</label><input name="title" required maxlength="120" value="分龄环创板设计"></div><div class="rowform"><div class="field"><label>目标年龄组</label><select name="ageGroup"><option>0–1 岁</option><option selected>1–3 岁</option><option>3–6 岁</option></select></div><div class="field"><label>作品版本 / 轮次</label><input name="attempt" type="number" min="1" step="1" required value="1"></div></div><div class="field"><label>上传作品（单件 ≤ 5 MB）</label><input type="file" id="work-file" accept=".png,.jpg,.jpeg,.webp,.pdf" required></div><div class="field"><label>我的设计说明</label><textarea name="description" required maxlength="4000" placeholder="说明设计目标、年龄适宜性、材料与操作方式"></textarea></div><label class="checkbox"><input type="checkbox" name="confirmed" required>我确认提交内容及作品来源。</label><div id="work-error" class="error" role="alert"></div><button class="btn section-gap" type="submit">提交作品</button></form>');
  }
  async function saveWork(form){
    if(!auth||isTeacher())throw Error('请用学生账号提交作品');
    const file=$('#work-file').files[0],v=Object.fromEntries(new FormData(form));if(!file)throw Error('请选择作品文件');
    if(!v.title?.trim()||v.title.length>120||!v.description?.trim()||v.description.length>4000||!v.confirmed)throw Error('请完成作品说明并确认提交内容');
    if(!['0–1 岁','1–3 岁','3–6 岁'].includes(v.ageGroup)||!Number.isInteger(Number(v.attempt))||Number(v.attempt)<1)throw Error('请核对年龄组与版本轮次');
    if(file.size>5*1024*1024)throw Error('作品文件超过 5 MB');if(!/\.(png|jpe?g|webp|pdf)$/i.test(file.name))throw Error('仅支持 PNG、JPG、WebP、PDF');
    const bytes=new Uint8Array(await file.slice(0,12).arrayBuffer()),head=Array.from(bytes).map(n=>n.toString(16).padStart(2,'0')).join('');
    if(!(head.startsWith('89504e47')||head.startsWith('ffd8ff')||head.startsWith('25504446')||(head.startsWith('52494646')&&head.slice(16,24)==='57454250')))throw Error('文件内容与作品格式不符');
    const id=crypto.randomUUID(),date=new Date().toLocaleString('sv-SE',{timeZone:'Asia/Shanghai'}).replace(' ','T');
    const work={id,ownerId:auth.id,studentId:auth.studentId,name:auth.name,title:v.title.trim(),ageGroup:v.ageGroup,date,filename:file.name,type:file.type,description:v.description.trim(),attempt:Number(v.attempt),recordIds:[],kind:mode};
    await fileOp('put',id,file);try{mutate(d=>d.works.push(work));}catch(e){await fileOp('delete',id);throw e;}
    student=work.studentId;closeModal();render();toast('作品已提交，等待教师评价');
  }
  async function backup(){
    const files=[];for(const w of db().works){const f=await fileOp('get',w.id);if(!f)throw Error('作品 '+w.filename+' 缺少文件，备份未完成');const base64=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f);});files.push({id:w.id,data:base64,type:f.type});}
    download('益童成长-'+(mode==='demo'?'演示':'真实')+'-完整备份.json',JSON.stringify({schema:'yitong-backup-v1',mode,createdAt:new Date().toISOString(),data:db(),files},null,2),'application/json');toast('备份已导出，含 '+files.length+' 个作品文件');
  }
  function selectFile(accept,handler){const input=document.createElement('input');input.type='file';input.accept=accept;input.onchange=()=>{const file=input.files[0];if(file)handler(file).catch(e=>toast(e.message));};input.click();}
  function validateBackup(b){
    if(b.schema!=='yitong-backup-v1'||b.mode!==mode||!b.data||!Array.isArray(b.data.records)||!Array.isArray(b.files))throw Error('备份格式或数据模式不匹配，请切换对应数据区');
    if(!Array.isArray(b.data.works)||!Array.isArray(b.data.tasks)||!Array.isArray(b.data.batches)||typeof b.data.notes!=='object')throw Error('备份数据结构无效');
    if(b.data.records.length>30000||b.data.works.length>100)throw Error('备份记录或作品数量超过限制');
    const ids=new Set();for(const r of b.data.records){if(!r.id||ids.has(r.id)||!r.studentId||!YT.domainId(r.domain)||!r.skill||!r.task||r.kind!==mode||!YT.dateValue(r.date)||!Number.isFinite(r.score)||!Number.isFinite(r.maxScore)||r.maxScore<=0||r.score<0||r.score>r.maxScore||!Number.isInteger(r.attempt)||r.attempt<1||!Number.isFinite(r.normalized)||Math.abs(r.normalized-r.score/r.maxScore*100)>.011)throw Error('备份成绩记录无效');ids.add(r.id);}
    const wids=new Set();for(const w of b.data.works){if(!w.id||wids.has(w.id)||w.kind!==mode||!Array.isArray(w.recordIds)||!b.files.some(f=>f.id===w.id))throw Error('备份作品记录或文件缺失');wids.add(w.id);}
    if(b.files.some(f=>!wids.has(f.id)||typeof f.data!=='string'||!/^data:(image\/(png|jpeg|webp)|application\/pdf);base64,/.test(f.data)))throw Error('备份含不支持的作品格式');
  }
  async function restoreFile(file){
    if(file.size>80*1024*1024)throw Error('备份超过 80 MB');const b=JSON.parse(await file.text());validateBackup(b);
    modal('恢复完整备份','<p>恢复 '+esc(file.name)+'：'+b.data.records.length+' 条成绩、'+b.data.works.length+' 件作品。</p><div class="note warn">这会替换当前'+(mode==='demo'?'演示':'真实')+'区的记录、任务和笔记。其他账号与其他数据区保持独立。请先导出现有数据备份。</div>',button('取消','close','outline')+button('恢复并替换当前区','restore-confirm','danger'));
    window.restorePending=b;
  }
  async function restoreConfirm(){
    const b=window.restorePending;if(!b)return;validateBackup(b);const fresh=YT.clone(b.data),written=[];
    try{
      for(const w of fresh.works){const oldId=w.id,newId=crypto.randomUUID(),file=b.files.find(f=>f.id===oldId);const binary=atob(file.data.split(',')[1]);if(binary.length>5*1024*1024)throw Error('作品文件超过 5 MB');const blob=new Blob([Uint8Array.from(binary,c=>c.charCodeAt(0))],{type:file.type});await fileOp('put',newId,blob);written.push(newId);w.id=newId;fresh.records.forEach(r=>{if(r.workId===oldId)r.workId=newId;});}
      const oldWorks=db().works;persist(fresh);for(const w of oldWorks)await fileOp('delete',w.id);
    }catch(e){for(const id of written)if(!db().works.some(w=>w.id===id))await fileOp('delete',id);throw e;}
    window.restorePending=null;student='';closeModal();render();toast('备份已恢复');
  }
  function configValid(c){c.xiaoguan={endpoint:c.xiaoguan?.endpoint||'',model:c.xiaoguan?.model||''};if(typeof c.xiaoguan.endpoint!=='string'||typeof c.xiaoguan.model!=='string'||!XiaoGuan.endpointValid(c.xiaoguan.endpoint)||c.xiaoguan.model.length>150||c.xiaoguan.endpoint.length>500||Boolean(c.xiaoguan.endpoint)!==Boolean(c.xiaoguan.model))throw Error('请同时填写图片模型地址与模型名称，或一起留空；地址须为 HTTPS 或 localhost。');if(!c.platforms||!c.rules||!Array.isArray(c.resources))throw Error('配置结构无效');YT.domains.forEach(d=>{const p=c.platforms[d.id];if(!p||typeof p.name!=='string'||typeof p.note!=='string'||typeof p.url!=='string'||(p.url&&!YT.safeURL(p.url)))throw Error('平台配置或网址无效');});if(![c.rules.pass,c.rules.target,c.rules.excellent].every(v=>Number.isFinite(v)&&v>=0&&v<=100)||!(c.rules.pass<=c.rules.target&&c.rules.target<=c.rules.excellent))throw Error('评分规则须满足 0 ≤ 合格 ≤ 目标 ≤ 优秀 ≤ 100');if(c.resources.some(r=>!menus.some(m=>m[0]===r.menu)||typeof r.title!=='string'||!YT.safeURL(r.url)))throw Error('资料配置无效');}
  function saveConfig(c){configValid(c);cleanDollPlatform(c);write('config',c);config=c;chat=[];render();toast('配置已保存');}
  async function onAction(el){
    const a=el.dataset.action;
    if(a==='close'){closeModal();return;}
    if(a==='show-register'){login(true);return;}if(a==='show-login'){login();return;}if(a==='login-type'){login(false,el.dataset.type);return;}
    if(a==='login-assist'){toast('登录后即可进入'+assists.find(x=>x[0]===el.dataset.assist)[1]+'工作台');return;}
    if(a==='motion-toggle'){motion=!motion;write('motion',motion);render();return;}
    if(a==='archive-info'){archiveInfo();return;}
    if(a==='platform-help'){const p=config.platforms[el.dataset.domain];modal(p.name,'<p>'+esc(p.note)+'</p><div class="note">因版权限制，配套平台仅限校园网内使用。请从电脑中已安装的软件快捷方式进入实训，完成后在这里录入导出记录。平台网址可在“平台配置”中填写。</div>');return;}
    if(a==='logout'){XiaoGuan.reset();stopGrowth();auth=null;write('session',null);tour=null;closeModal();login();return;}
    if(a==='nav'){toPage(el.dataset.page);return;}
    if(a==='mode'){if(mode===el.dataset.mode)return;XiaoGuan.reset();stopGrowth();mode=el.dataset.mode;write('mode',mode);student='';chat=[];chartSelection='';closeModal();render();return;}
    if(a==='domain'||a==='enter-domain'){toPage('smart',el.dataset.domain);return;}
    if(a==='assist'){selectedAssist=el.dataset.assist;chat=[];toPage('assistant');return;}
    if(a==='platform'){const p=config.platforms[el.dataset.domain],url=YT.safeURL(p.url);if(url){window.open(url,'_blank','noopener,noreferrer');}else{modal('平台使用说明','<p>'+esc(p.note)+'</p><p class="small muted">收到实际网址后，可在平台配置中填写。独立软件请使用 Windows 中已有的程序快捷方式。</p>',button('去配置','config-nav'));}return;}
    if(a==='config-nav'){closeModal();toPage('settings');return;}
    if(a==='rules'){rulesModal();return;}if(a==='plan'){planModal(el.dataset.id);return;}if(a==='add-task'){addTask(el.dataset.id);return;}
    if(a==='remove-task'){mutate(d=>d.tasks=d.tasks.filter(t=>t.id!==el.dataset.id));render();toast('复练任务已移除');return;}
    if(a==='assistant-task'){addTask(data().weaknesses[0]?.id);return;}
    if(a==='ask-quick'){ask(el.dataset.question);return;}
    if(a==='lesson'){lessonOpen=lessonOpen===el.dataset.id?'':el.dataset.id;render();return;}
    if(a==='view-sample'){const w=YT_GALLERY.find(x=>x.id===el.dataset.id);if(w)modal(w.title,'<img class="sample-full" src="'+w.src+'" alt="'+esc(w.title)+'课程示例"><p>'+esc(w.description)+'</p><div class="note">课程示例设计图，用于展示与讨论，不代表已提交的学生成果，不计入成绩。</div>','',true);return;}
    if(a==='review-work'){reviewModal(el.dataset.id,el.dataset.key);return;}
    if(a==='review-file'){const {work:w}=reviewTarget(el.dataset.id,el.dataset.key),f=await fileOp('get',w.id);if(!f)throw Error('作品文件缺失');if(f.type.startsWith('image/')){const url=URL.createObjectURL(f);viewURL.push(url);modal(w.title,'<img class="sample-full" src="'+url+'" alt="学生提交作品"><p>'+esc(w.description)+'</p>','',true);}else download(w.filename,f);return;}
    if(a==='open-import'){importModal();return;}if(a==='confirm-import'){confirmImport();return;}if(a==='upload-work'){uploadModal();return;}
    if(a==='export-csv'||a==='export-all'){const rows=a==='export-all'?db().records:data().rows;if(!rows.length){toast('当前数据区没有可导出的成绩');return;}download('益童成长-'+mode+'-成绩.csv',YT.exportCSV(rows),'text/csv;charset=utf-8');return;}
    if(a==='backup'){await backup();return;}if(a==='restore'){selectFile('.json',restoreFile);return;}if(a==='restore-confirm'){await restoreConfirm();return;}
    if(a==='print'){window.print();return;}
    if(a==='download-work'){const w=db().works.find(w=>w.id===el.dataset.id),f=w&&await fileOp('get',w.id);if(!f)throw Error('作品文件缺失，请恢复完整备份');download(w.filename,f);return;}
    if(a==='delete-work'){const w=db().works.find(w=>w.id===el.dataset.id);modal('删除作品','<p>删除「'+esc(w.title)+'」及该作品关联的教师评分。</p>',button('取消','close','outline')+button('确认删除','delete-work-confirm','danger','data-id="'+esc(w.id)+'"'));return;}
    if(a==='delete-work-confirm'){const w=db().works.find(w=>w.id===el.dataset.id);mutate(d=>{d.works=d.works.filter(x=>x.id!==w.id);d.records=d.records.filter(r=>!w.recordIds.includes(r.id));});await fileOp('delete',w.id);closeModal();render();toast('作品与关联评分已删除');return;}
    if(a==='undo-batch'){const b=db().batches.find(b=>b.id===el.dataset.id);modal('撤销导入批次','<p>撤销「'+esc(b.filename)+'」的 '+b.ids.length+' 条记录。画像会重新计算。</p>',button('取消','close','outline')+button('确认撤销','undo-confirm','danger','data-id="'+esc(b.id)+'"'));return;}
    if(a==='undo-confirm'){const b=db().batches.find(b=>b.id===el.dataset.id);mutate(d=>{d.records=d.records.filter(r=>!b.ids.includes(r.id));d.batches=d.batches.filter(x=>x.id!==b.id);d.tasks=d.tasks.filter(t=>!b.ids.includes(t.recordId));});closeModal();render();toast('批次已撤销');return;}
    if(a==='growth-start'){stopGrowth();checkpoint=periods()[0]||'2026-03';write('checkpoint',checkpoint);chat=[];render();return;}
    if(a==='growth-latest'){stopGrowth();checkpoint=periods().at(-1)||'2026-07';write('checkpoint',checkpoint);chat=[];render();return;}
    if(a==='growth-next'){stopGrowth();const series=YT.growthSeries(db().records,selectedStudent(),config.rules),current=series.find(s=>s.month===checkpoint)||series.at(-1);const next=series.find(s=>s.month>current.month&&s.rank.level>current.rank.level)||series.find(s=>s.month>current.month&&s.month===series.at(-1).month);if(!next){toast('已回看到最新精英阶段');return;}checkpoint=next.month;write('checkpoint',checkpoint);chat=[];render();toast('回看 '+checkpoint+' · '+next.rank.name+' '+score(next.value)+' 分');return;}
    if(a==='growth-play'){if(growthPlayer){stopGrowth();render();return;}if(mode!=='demo')return;const months=periods();checkpoint=months[0];growthPlayer=setInterval(()=>{const i=months.indexOf(checkpoint);if(i>=months.length-1){stopGrowth();render();return;}checkpoint=months[i+1];chat=[];render();},1200);render();return;}
    if(a==='reset-demo'){modal('重置演示脚本','<p>将演示区恢复到首轮记录。演示作品、导入批次、任务和笔记会清空。真实导入区保留。</p>',button('取消','close','outline')+button('重置演示区','reset-demo-confirm','danger'));return;}
    if(a==='reset-demo-confirm'){await resetDemo();closeModal();render();toast('演示数据已重置');return;}
    if(a==='delete-resource'){const c=YT.clone(config);c.resources.splice(Number(el.dataset.index),1);saveConfig(c);return;}
    if(a==='export-config'){download('益童成长-平台配置.json',JSON.stringify(config,null,2),'application/json');return;}
    if(a==='import-config'){selectFile('.json',async file=>{if(file.size>1024*1024)throw Error('配置文件超过 1 MB');saveConfig(JSON.parse(await file.text()));});return;}
    if(a==='tour-start'){modal('成长汇报','<p>沿学期档案回看关键训练阶段。计时可暂停，记录不重置。</p><div class="note">本次使用历史档案 · 示例数据，成绩录入区保持独立。</div>',button('取消','close','outline')+button('开始汇报','tour-start-confirm','gold'));return;}
    if(a==='tour-start-confirm'){stopGrowth();mode='demo';write('mode',mode);student='2023001';checkpoint=tourSteps[0].month;tour={step:0,started:Date.now(),running:true,elapsed:0};closeModal();toPage('home');return;}
    if(a==='tour-goto'){const st=tourSteps[Number(el.dataset.step)];stopGrowth();mode='demo';write('mode',mode);student='2023001';checkpoint=st.month;toPage(st.page,st.domain);return;}
    if(a==='tour-next'||a==='tour-prev'){if(!tour)return;stopGrowth();tour.step=Math.max(0,Math.min(5,tour.step+(a==='tour-next'?1:-1)));const st=tourSteps[tour.step];mode='demo';write('mode',mode);checkpoint=st.month;student='2023001';toPage(st.page,st.domain);return;}
    if(a==='tour-pause'){if(tour.running){tour.elapsed=Date.now()-tour.started;tour.running=false;}else{tour.started=Date.now()-tour.elapsed;tour.running=true;}render();return;}
    if(a==='tour-hint'){const st=tourSteps[tour.step];modal(st.title,'<span class="pill">'+st.time+'</span><p class="section-gap">'+st.script+'</p>');return;}
    if(a==='tour-end'){tour=null;render();return;}
  }
  function ask(q){
    const supported=/复练|补强|计划|诊断|画像|依据|比较|变化|观察|课堂|任务|活动|汇总|覆盖|清单|环创|方案|沟通|设计|导入|设备|同步|接口|实时/.test(q);
    chat.push({role:'user',text:q},{role:'assistant',text:supported?assistantAnswer(selectedAssist,q):'离线规则助手当前支持：训练诊断、复练计划、课堂任务、记录汇总和环创设计提纲。请使用上方建议问题，开放问答需要另行接入模型。'});chat=chat.slice(-12);render();$('#chat-form').scrollIntoView({block:'nearest'});
  }
  function stopGrowth(){if(growthPlayer)clearInterval(growthPlayer);growthPlayer=null;}
  async function resetDemo(){stopGrowth();checkpoint='2026-07';const old=demo.works;write('demo',{records:YT.demoData(),works:[],tasks:[],notes:{},batches:[],datasetVersion:YT.growthVersion});demo=read('demo',{});for(const w of old)await fileOp('delete',w.id);chat=[];chartSelection='';}
  document.addEventListener('click',async e=>{const el=e.target.closest('[data-action]');if(!el||el.disabled)return;e.preventDefault();try{await onAction(el);}catch(err){toast(err.message);}});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();if(e.key==='Enter'&&e.target.matches('[role=button][data-action]'))e.target.click();});
  document.addEventListener('change',async e=>{
    try{
      if(e.target.id==='student-select'){stopGrowth();student=e.target.value;chat=[];chartSelection='';render();}
      if(e.target.id==='checkpoint-select'){stopGrowth();checkpoint=e.target.value;write('checkpoint',checkpoint);chat=[];chartSelection='';render();}
      if(e.target.id==='chart-select'){chartSelection=e.target.value;render();}
      if(e.target.id==='import-file')await readImport(e.target.files[0]);
      if(e.target.dataset.map){importState.map[e.target.dataset.map]=Number(e.target.value);validateImport();}
      if(e.target.id==='import-sheet'){const s=importState;s.sheet=Number(e.target.value);try{s.table=await s.workbook.table(s.sheet);s.map=YT.autoMap(s.table.headers);drawImport();}catch(err){s.validation={valid:[],errors:[{row:1,message:err.message}],warnings:[],duplicates:0};$('#import-content').innerHTML='';$('#import-error').textContent=err.message;}}
      if(e.target.id==='import-confirm')updateImportButton();if(e.target.id==='batch-source')validateImport();
    }catch(err){toast(err.message);}
  });
  document.addEventListener('submit',async e=>{
    e.preventDefault();const form=e.target;
    try{
      if(form.id==='auth-form'){await authenticate(form);return;}
      const v=Object.fromEntries(new FormData(form));
      if(form.id==='chat-form'){ask(v.question);return;}
      if(form.id==='review-form'){try{saveReview(form);}catch(err){$('#review-error').textContent=err.message;}return;}
      if(form.id==='work-form'){const btn=form.querySelector('[type=submit]');btn.disabled=true;try{await saveWork(form);}catch(err){$('#work-error').textContent=err.message;btn.disabled=false;}return;}
      if(form.dataset.form==='lesson'){mutate(d=>d.notes[form.dataset.key]={text:v.note,done:v.done==='on',date:new Date().toISOString()});render();toast('学习记录已保存');return;}
      if(form.id==='xg-settings-form'){const c=YT.clone(config);c.xiaoguan={endpoint:v.endpoint.trim(),model:v.model.trim()};configValid(c);XiaoGuan.setToken(v.token);saveConfig(c);return;}
      if(form.id==='settings-form'){const c=YT.clone(config);YT.domains.forEach(d=>{c.platforms[d.id]={name:v[d.id+'-name'].trim(),url:v[d.id+'-url'].trim(),note:v[d.id+'-note']};});saveConfig(c);return;}
      if(form.id==='rules-form'){const c=YT.clone(config);c.rules={pass:Number(v.pass),target:Number(v.target),excellent:Number(v.excellent)};saveConfig(c);return;}
      if(form.id==='resource-form'){const c=YT.clone(config);c.resources.push({id:crypto.randomUUID(),menu:v.menu,title:v.title,url:v.url,date:v.date});saveConfig(c);return;}
    }catch(err){toast(err.message);}
  });
  setInterval(()=>{if(tour&&$('#tour-time')){const t=elapsed();$('#tour-time').textContent=timeString(t);$('#tour-time').style.color=t>300?'#ffe094':'white';}},1000);
  render();
})();
